<?php
/**
 * Register custom order status for Quote Requests
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Order {
    public static function init() {
        add_action( 'init', [ __CLASS__, 'register_quote_order_status' ] );
        add_filter( 'wc_order_statuses', [ __CLASS__, 'add_quote_order_status' ] );
        add_filter( 'wc_order_is_editable', [ __CLASS__, 'quote_is_editable' ], 10, 2 );
        add_filter( 'woocommerce_order_actions', [ __CLASS__, 'add_quote_order_action' ] );
        add_action( 'woocommerce_order_action_wpcrq_send_quote', [ __CLASS__, 'process_send_quote_action' ] );

        // Admin UI Enhancements
        add_action( 'admin_head', [ __CLASS__, 'admin_status_colors' ] );
    }

    public static function admin_status_colors() {
        $screen = get_current_screen();

        if ( ! $screen || ! in_array( $screen->id, [
                        'edit-shop_order',
                        'shop_order',
                        'woocommerce_page_wc-orders',
                        'woocommerce_page_wc-orders--shop_order'
                ], true ) ) {
            return;
        }
        ?>
        <style>
            /* Custom order status colors for WPC Request a Quote */
            .wp-list-table .column-order_status mark.order-status.status-wc-quote-request,
            .wp-list-table .column-order_status mark.order-status.status-quote-request {
                border-left: 4px solid #ffba00 !important;
            }

            .wp-list-table .column-order_status mark.order-status.status-wc-quote-pending,
            .wp-list-table .column-order_status mark.order-status.status-quote-pending {
                border-left: 4px solid #96588a !important;
            }

            .wp-list-table .column-order_status mark.order-status.status-wc-quote-rejected,
            .wp-list-table .column-order_status mark.order-status.status-quote-rejected {
                border-left: 4px solid #333333 !important;
            }
        </style>
        <?php
    }

    public static function register_quote_order_status() {
        register_post_status( 'wc-quote-request', [
                'label'                     => _x( 'Quote Request', 'Order status', 'wpc-request-a-quote' ),
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                /* translators: %s: order count */
                'label_count'               => _n_noop( 'Quote Request <span class="count">(%s)</span>', 'Quote Requests <span class="count">(%s)</span>', 'wpc-request-a-quote' ),
        ] );

        register_post_status( 'wc-quote-pending', [
                'label'                     => _x( 'Quote Pending Review', 'Order status', 'wpc-request-a-quote' ),
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                /* translators: %s: order count */
                'label_count'               => _n_noop( 'Quote Pending Review <span class="count">(%s)</span>', 'Quote Pending Reviews <span class="count">(%s)</span>', 'wpc-request-a-quote' ),
        ] );

        register_post_status( 'wc-quote-rejected', [
                'label'                     => _x( 'Quote Rejected', 'Order status', 'wpc-request-a-quote' ),
                'public'                    => false,
                'exclude_from_search'       => false,
                'show_in_admin_all_list'    => true,
                'show_in_admin_status_list' => true,
                /* translators: %s: order count */
                'label_count'               => _n_noop( 'Quote Rejected <span class="count">(%s)</span>', 'Quotes Rejected <span class="count">(%s)</span>', 'wpc-request-a-quote' ),
        ] );
    }

    public static function add_quote_order_status( $order_statuses ) {
        $new_statuses = [];

        foreach ( $order_statuses as $key => $status ) {
            $new_statuses[ $key ] = $status;
            if ( 'wc-processing' === $key ) {
                $new_statuses['wc-quote-request']  = _x( 'Quote Request', 'Order status', 'wpc-request-a-quote' );
                $new_statuses['wc-quote-pending']  = _x( 'Quote Pending Review', 'Order status', 'wpc-request-a-quote' );
                $new_statuses['wc-quote-rejected'] = _x( 'Quote Rejected', 'Order status', 'wpc-request-a-quote' );
            }
        }

        if ( ! isset( $new_statuses['wc-quote-request'] ) ) {
            $new_statuses['wc-quote-request']  = _x( 'Quote Request', 'Order status', 'wpc-request-a-quote' );
            $new_statuses['wc-quote-pending']  = _x( 'Quote Pending Review', 'Order status', 'wpc-request-a-quote' );
            $new_statuses['wc-quote-rejected'] = _x( 'Quote Rejected', 'Order status', 'wpc-request-a-quote' );
        }

        return $new_statuses;
    }

    public static function quote_is_editable( $is_editable, $order ) {
        // Allow editing so admin can add shipping, prices, and switch to "Pending Payment".
        if ( in_array( $order->get_status(), [ 'quote-request', 'quote-pending', 'quote-rejected' ], true ) ) {
            $is_editable = true;
        }

        return $is_editable;
    }

    public static function add_quote_order_action( $actions ) {
        global $theorder;
        if ( ! $theorder ) {
            return $actions;
        }

        if ( $theorder->get_status() === 'quote-request' || $theorder->get_status() === 'quote-rejected' ) {
            $actions['wpcrq_send_quote'] = __( 'Send Quote to Customer', 'wpc-request-a-quote' );
        }

        return $actions;
    }

    public static function process_send_quote_action( $order ) {
        $order->update_status( 'quote-pending', __( 'Quote updated and sent to customer.', 'wpc-request-a-quote' ) );

        // Ensure mailer is loaded so our custom email hook is active
        WC()->mailer();

        do_action( 'wpcrq_send_updated_quote_email', $order->get_id() );

        // Log for statistics
        WPCRQ_Statistics::log_event( $order->get_id(), 'reviewed' );
    }
}

WPCRQ_Order::init();
