<?php
defined( 'ABSPATH' ) || exit;

class WPCRQ_Request_A_Quote {
	public static $version = WPCRQ_VERSION;
	private static $_instance = null;

	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public static function init() {
		self::instance();
	}

	public function __construct() {
		$this->includes();

		add_filter( 'woocommerce_payment_gateways', [ $this, 'register_gateway' ] );
	}

	private function includes() {
		require_once WPCRQ_DIR . 'includes/class-wpcrq-statistics.php';
		require_once WPCRQ_DIR . 'includes/class-wpcrq-settings.php';
		require_once WPCRQ_DIR . 'includes/class-wpcrq-order.php';
		require_once WPCRQ_DIR . 'includes/class-wpcrq-session.php';
		require_once WPCRQ_DIR . 'includes/class-wpcrq-frontend.php';
		require_once WPCRQ_DIR . 'includes/class-wpcrq-shortcode.php';
		require_once WPCRQ_DIR . 'includes/class-wpcrq-emails.php';
		require_once WPCRQ_DIR . 'includes/class-wpcrq-product-meta.php';
		// More files will be required here later as we build features
	}

	public function register_gateway( $gateways ) {
		$enable_gateway = WPCRQ_Settings::get_setting( 'enable_payment_gateway', 'no' );

		if ( 'yes' === $enable_gateway ) {
			if ( class_exists( 'WC_Payment_Gateway' ) ) {
				require_once WPCRQ_DIR . 'includes/class-wc-gateway-request-a-quote.php';
				$gateways[] = 'WC_Gateway_Request_A_Quote';
			}
		}

		return $gateways;
	}

}
