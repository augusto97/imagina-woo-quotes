<?php
/**
 * Localization class
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Localization {
	public static function init() {
		add_action( 'plugins_loaded', [ __CLASS__, 'load_textdomain' ] );
	}

	public static function load_textdomain() {
		load_plugin_textdomain( 'wpc-request-a-quote', false, dirname( plugin_basename( WPCRQ_FILE ) ) . '/languages/' );
	}

	/**
	 * Get all localizable strings with their default values.
	 */
	public static function get_localized_strings() {
		return [
			// Buttons
			'add_to_quote'              => [
				'label'   => __( 'Add to Quote button', 'wpc-request-a-quote' ),
				'default' => __( 'Add to Quote', 'wpc-request-a-quote' ),
			],
			'added_to_quote'            => [
				'label'   => __( 'Added to Quote button text', 'wpc-request-a-quote' ),
				'default' => __( 'Added to Quote', 'wpc-request-a-quote' ),
			],
			'browse_quote'              => [
				'label'   => __( 'Browse quote list link', 'wpc-request-a-quote' ),
				'default' => __( 'Browse quote list', 'wpc-request-a-quote' ),
			],
			'submit_request'            => [
				'label'   => __( 'Submit Request button', 'wpc-request-a-quote' ),
				'default' => __( 'Submit request', 'wpc-request-a-quote' ),
			],
			'request_quote_this_cart'   => [
				'label'   => __( 'Request Quote this Cart button', 'wpc-request-a-quote' ),
				'default' => __( 'Request Quote this Cart', 'wpc-request-a-quote' ),
			],
			'update_list'               => [
				'label'   => __( 'Update List button', 'wpc-request-a-quote' ),
				'default' => __( 'Update List', 'wpc-request-a-quote' ),
			],

			// Table Headers
			'product'                   => [
				'label'   => __( 'Product column header', 'wpc-request-a-quote' ),
				'default' => __( 'Product', 'wpc-request-a-quote' ),
			],
			'price'                     => [
				'label'   => __( 'Price column header', 'wpc-request-a-quote' ),
				'default' => __( 'Price', 'wpc-request-a-quote' ),
			],
			'quantity'                  => [
				'label'   => __( 'Quantity column header', 'wpc-request-a-quote' ),
				'default' => __( 'Quantity', 'wpc-request-a-quote' ),
			],
			'total'                     => [
				'label'   => __( 'Total column header', 'wpc-request-a-quote' ),
				'default' => __( 'Total', 'wpc-request-a-quote' ),
			],
			'subtotal'                  => [
				'label'   => __( 'Subtotal column header', 'wpc-request-a-quote' ),
				'default' => __( 'Subtotal', 'wpc-request-a-quote' ),
			],

			// Form Labels
			'first_name'                => [
				'label'   => __( 'First Name label', 'wpc-request-a-quote' ),
				'default' => __( 'First Name', 'wpc-request-a-quote' ),
			],
			'last_name'                 => [
				'label'   => __( 'Last Name label', 'wpc-request-a-quote' ),
				'default' => __( 'Last Name', 'wpc-request-a-quote' ),
			],
			'email'                     => [
				'label'   => __( 'Email Address label', 'wpc-request-a-quote' ),
				'default' => __( 'Email Address', 'wpc-request-a-quote' ),
			],
			'phone'                     => [
				'label'   => __( 'Phone Number label', 'wpc-request-a-quote' ),
				'default' => __( 'Phone Number', 'wpc-request-a-quote' ),
			],
			'message'                   => [
				'label'   => __( 'Message label', 'wpc-request-a-quote' ),
				'default' => __( 'Message', 'wpc-request-a-quote' ),
			],
			'send_your_request'         => [
				'label'   => __( 'Send Your Request title', 'wpc-request-a-quote' ),
				'default' => __( 'Send your request', 'wpc-request-a-quote' ),
			],

			// Success/Empty Messages
			'quote_requested_success'   => [
				'label'   => __( 'Quote Requested Success message', 'wpc-request-a-quote' ),
				'default' => __( 'Your quote has been requested successfully!', 'wpc-request-a-quote' ),
			],
			'your_quote_empty'          => [
				'label'   => __( 'Quote List Empty message', 'wpc-request-a-quote' ),
				'default' => __( 'Your quote list is currently empty.', 'wpc-request-a-quote' ),
			],
			'return_to_shop'            => [
				'label'   => __( 'Return to shop text', 'wpc-request-a-quote' ),
				'default' => __( 'Return to shop', 'wpc-request-a-quote' ),
			],

			// Errors
			'no_permission'             => [
				'label'   => __( 'No Permission message', 'wpc-request-a-quote' ),
				'default' => __( 'You do not have permission to request a quote.', 'wpc-request-a-quote' ),
			],
			'first_name_email_required' => [
				'label'   => __( 'Required fields message', 'wpc-request-a-quote' ),
				'default' => __( 'First name and email are required.', 'wpc-request-a-quote' ),
			],
			'invalid_email'             => [
				'label'   => __( 'Invalid Email message', 'wpc-request-a-quote' ),
				'default' => __( 'Invalid email address.', 'wpc-request-a-quote' ),
			],
			'quote_list_empty'          => [
				'label'   => __( 'Quote List is Empty error', 'wpc-request-a-quote' ),
				'default' => __( 'Your quote list is empty.', 'wpc-request-a-quote' ),
			],
			'failed_to_create'          => [
				'label'   => __( 'Failed to Create Quote error', 'wpc-request-a-quote' ),
				'default' => __( 'Failed to create quote request.', 'wpc-request-a-quote' ),
			],
			'message_too_long'          => [
				'label'   => __( 'Message too long error', 'wpc-request-a-quote' ),
				/* translators: %s: maximum number of characters */
				'default' => __( 'Message is too long. The maximum allowed length is %s characters.', 'wpc-request-a-quote' ),
			],
			'generic_error'             => [
				'label'   => __( 'Generic error message', 'wpc-request-a-quote' ),
				'default' => __( 'An error occurred. Please try again.', 'wpc-request-a-quote' ),
			],
			'update_error'              => [
				'label'   => __( 'Update error message', 'wpc-request-a-quote' ),
				'default' => __( 'Error updating quote.', 'wpc-request-a-quote' ),
			],
			'min_qty_error'             => [
				'label'   => __( 'Minimum total quantity error', 'wpc-request-a-quote' ),
				/* translators: %s: minimum quantity */
				'default' => __( 'Total quantity must be at least %s.', 'wpc-request-a-quote' ),
			],
			'max_qty_error'             => [
				'label'   => __( 'Maximum total quantity error', 'wpc-request-a-quote' ),
				/* translators: %s: maximum quantity */
				'default' => __( 'Total quantity cannot exceed %s.', 'wpc-request-a-quote' ),
			],

			// Product statuses
			'product_added'             => [
				'label'   => __( 'Product added message', 'wpc-request-a-quote' ),
				'default' => __( 'Product added to quote.', 'wpc-request-a-quote' ),
			],
			'product_removed'           => [
				'label'   => __( 'Product removed message', 'wpc-request-a-quote' ),
				'default' => __( 'Product removed from quote.', 'wpc-request-a-quote' ),
			],
			'quote_list_updated'        => [
				'label'   => __( 'Quote list updated message', 'wpc-request-a-quote' ),
				'default' => __( 'Quote list updated.', 'wpc-request-a-quote' ),
			],
			'remove_item'               => [
				'label'   => __( 'Remove item aria-label', 'wpc-request-a-quote' ),
				'default' => __( 'Remove this item', 'wpc-request-a-quote' ),
			],
			'send_request'              => [
				'label'   => __( 'Send Request button', 'wpc-request-a-quote' ),
				'default' => __( 'Send Request', 'wpc-request-a-quote' ),
			],

			// Quote View Page
			'quote_details_title'       => [
				'label'   => __( 'Quote Details title', 'wpc-request-a-quote' ),
				/* translators: %s: quote number */
				'default' => __( 'Quote #%s Details', 'wpc-request-a-quote' ),
			],
			'review_quote_msg'          => [
				'label'   => __( 'Review Quote message', 'wpc-request-a-quote' ),
				'default' => __( 'Please review your updated quote below. You can accept it to proceed to payment or reject it if you no longer wish to proceed.', 'wpc-request-a-quote' ),
			],
			'status_label'              => [
				'label'   => __( 'Status label', 'wpc-request-a-quote' ),
				/* translators: %s: quote status */
				'default' => __( 'Status: %s', 'wpc-request-a-quote' ),
			],
			'no_shipping_address'       => [
				'label'   => __( 'No shipping address message', 'wpc-request-a-quote' ),
				'default' => __( 'No shipping address set.', 'wpc-request-a-quote' ),
			],
			'shipping_info_title'       => [
				'label'   => __( 'Shipping Information title', 'wpc-request-a-quote' ),
				'default' => __( 'Shipping Information', 'wpc-request-a-quote' ),
			],
			'shipping_info_msg'         => [
				'label'   => __( 'Shipping Information message', 'wpc-request-a-quote' ),
				'default' => __( 'Please provide your shipping address to proceed to payment.', 'wpc-request-a-quote' ),
			],
			'confirm_pay_btn'           => [
				'label'   => __( 'Confirm & Pay button', 'wpc-request-a-quote' ),
				'default' => __( 'Confirm & Go to Payment', 'wpc-request-a-quote' ),
			],
			'back_to_quote_link'        => [
				'label'   => __( 'Back to Quote link', 'wpc-request-a-quote' ),
				'default' => __( 'Back to Quote', 'wpc-request-a-quote' ),
			],
			'accept_pay_btn'            => [
				'label'   => __( 'Accept & Pay button', 'wpc-request-a-quote' ),
				'default' => __( 'Accept Quote & Pay', 'wpc-request-a-quote' ),
			],
			'reject_quote_btn'          => [
				'label'   => __( 'Reject Quote button', 'wpc-request-a-quote' ),
				'default' => __( 'Reject Quote', 'wpc-request-a-quote' ),
			],
			'accepted_awaiting_pay'     => [
				'label'   => __( 'Accepted & Awaiting Payment message', 'wpc-request-a-quote' ),
				'default' => __( 'This quote has been accepted and is awaiting payment.', 'wpc-request-a-quote' ),
			],
			'pay_now_btn'               => [
				'label'   => __( 'Pay Now button', 'wpc-request-a-quote' ),
				'default' => __( 'Pay Now', 'wpc-request-a-quote' ),
			],
			'update_shipping_btn'       => [
				'label'   => __( 'Update Shipping Address button', 'wpc-request-a-quote' ),
				'default' => __( 'Update Shipping Address', 'wpc-request-a-quote' ),
			],
			'quote_rejected_msg'        => [
				'label'   => __( 'Quote Rejected message', 'wpc-request-a-quote' ),
				'default' => __( 'This quote has been rejected.', 'wpc-request-a-quote' ),
			],
			'order_status_msg'          => [
				'label'   => __( 'Order Status message', 'wpc-request-a-quote' ),
				/* translators: %s: order status */
				'default' => __( 'This order is currently %s.', 'wpc-request-a-quote' ),
			],
		];
	}

	public static function get_text( $key, $default = '' ) {
		$localization = get_option( 'wpcrq_localization', [] );
		$strings      = self::get_localized_strings();

		if ( isset( $localization[ $key ] ) && ! empty( $localization[ $key ] ) ) {
			return $localization[ $key ];
		}

		if ( isset( $strings[ $key ] ) ) {
			return $strings[ $key ]['default'];
		}

		return ! empty( $default ) ? $default : $key;
	}
}
