<?php
/**
 * WPC Premium — Shared premium class for license keys, update checker, and admin notices.
 *
 * @package WPC_Premium
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WPCleverPremium' ) ) {
    class WPCleverPremium {
        function __construct() {
            add_action( 'init', [ $this, 'register_update_checkers' ], 99 );
            add_action( 'init', [ $this, 'register_update_message_hooks' ], 99 );
            add_action( 'admin_notices', [ $this, 'show_update_notices' ], 99 );
            add_action( 'admin_menu', [ $this, 'admin_menu' ] );
            add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_scripts' ] );
            add_action( 'wp_ajax_wpc_check_update_key', [ $this, 'check_update_key' ] );
            add_action( 'wp_ajax_wpc_remove_key', [ $this, 'remove_key' ] );
            add_action( 'wp_ajax_wpc_dismiss_notice', [ $this, 'dismiss_notice' ] );
            add_action( 'rest_api_init', [ $this, 'register_rest_route' ] );

            // Add License Keys tab to shared nav
            add_filter( 'wpc_admin_nav_items', [ $this, 'add_nav_item' ] );
        }

        /**
         * Register update checkers for all registered plugins.
         */
        function register_update_checkers() {
            $plugins = WPC_Premium_Registry::instance()->get_plugins();

            foreach ( $plugins as $plugin ) {
                $id   = $plugin['id'];
                $file = $plugin['file'];
                $dir  = $plugin['dir'];

                if ( $key = self::get_update_key( $id ) ) {
                    PucFactory::buildUpdateChecker(
                            'https://api.wpclever.net/update/' . $key . '.json',
                            $file,
                            plugin_basename( $dir )
                    );
                } else {
                    PucFactory::buildUpdateChecker(
                            'https://api.wpclever.net/update/' . $id . '.json',
                            $file,
                            plugin_basename( $dir )
                    );
                }
            }
        }

        /**
         * Register in_plugin_update_message hooks for each plugin.
         */
        function register_update_message_hooks() {
            $plugins = WPC_Premium_Registry::instance()->get_plugins();

            foreach ( $plugins as $plugin ) {
                $basename = plugin_basename( $plugin['file'] );
                add_action(
                        'in_plugin_update_message-' . $basename,
                        function () use ( $plugin ) {
                            if ( ! self::get_update_key( $plugin['id'] ) ) {
                                echo ' <em>Please verify your license key in <a href="' . esc_url( admin_url( 'admin.php?page=wpclever-keys' ) ) . '" target="_blank">WPClever > License Keys</a> to update.</em>';
                            }
                        },
                        99
                );
            }
        }

        /**
         * Show admin notices for unverified plugins.
         */
        function show_update_notices() {
            if ( apply_filters( 'wpc_dismiss_notices', false ) ) {
                return;
            }

            $plugins = WPC_Premium_Registry::instance()->get_plugins();

            foreach ( $plugins as $plugin ) {
                $dismiss_key = 'wpc_dismiss_notice_' . $plugin['prefix'] . '_update';

                if ( get_option( $dismiss_key ) ) {
                    continue;
                }

                if ( ! self::get_update_key( $plugin['id'] ) ) {
                    ?>
                    <div data-dismissible="<?php echo esc_attr( $plugin['prefix'] ); ?>_update"
                         class="wpc-notice notice notice-warning is-dismissible">
                        <p>Please verify
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpclever-keys' ) ); ?>">License
                                Key</a> of
                            <strong><?php echo esc_html( $plugin['name'] ); ?></strong> to enjoy unlimited update
                            release and get the latest plugin update directly on the website backend.
                        </p>
                    </div>
                    <?php
                }
            }
        }

        function register_rest_route() {
            register_rest_route( 'wpc/db', '/(?P<id>\d+)', [
                    'methods'             => 'GET',
                    'callback'            => [ $this, 'wpc_rest_route_debug_callback' ],
                    'permission_callback' => [ $this, 'check_debug_permission' ],
            ] );
            register_rest_route( 'wpc/uv', '/(?P<key>.+)', [
                    'methods'             => 'GET',
                    'callback'            => [ $this, 'wpc_rest_route_unverify_callback' ],
                    'permission_callback' => [ $this, 'check_unverify_permission' ],
            ] );
        }

        /**
         * Check permission for debug endpoint.
         * Global rate limiting: max 1 request per 5 minutes.
         */
        function check_debug_permission( $request ) {
            if ( get_transient( 'wpc_db_rate' ) ) {
                return new WP_Error( 'rate_limited', 'Too many requests. Try again later.', [ 'status' => 429 ] );
            }

            set_transient( 'wpc_db_rate', 1, 5 * MINUTE_IN_SECONDS );

            return true;
        }

        /**
         * Check permission for unverify endpoint.
         * Global rate limiting: max 1 request per 5 minutes.
         */
        function check_unverify_permission( $request ) {
            if ( get_transient( 'wpc_uv_rate' ) ) {
                return new WP_Error( 'rate_limited', 'Too many requests. Try again later.', [ 'status' => 429 ] );
            }

            set_transient( 'wpc_uv_rate', 1, 5 * MINUTE_IN_SECONDS );

            return true;
        }

        function wpc_rest_route_debug_callback( $data ) {
            if ( ! empty( $data['id'] ) && ( absint( $data['id'] ) == absint( gmdate( 'j' ) ) + absint( gmdate( 'n' ) ) ) ) {
                $result         = [ 'success' => true ];
                $wpc_keys       = [];
                $wpc_plugins    = [];
                $keys           = (array) get_option( 'wpc_update_keys', [] );
                $active_plugins = (array) get_option( 'active_plugins', [] );

                if ( ! empty( $active_plugins ) ) {
                    foreach ( $active_plugins as $active_plugin ) {
                        if ( ( ( str_contains( $active_plugin, 'wpc-' ) || str_contains( $active_plugin, 'woo-' ) ) && str_contains( $active_plugin, '-premium' ) ) || str_contains( $active_plugin, 'wpc-' ) ) {
                            $wpc_plugins[] = $active_plugin;
                        }
                    }
                }

                $result['plugins'] = $wpc_plugins;

                if ( ! empty( $keys ) ) {
                    foreach ( $keys as $key => $value ) {
                        $wpc_key = substr( $key, 0, 3 ) . $value['id'] . substr( $key, strlen( $key ) - 3, 3 );
                        unset( $keys[ $key ]['id'] );

                        foreach ( $value['plugins'] as $k => $plugin ) {
                            $keys[ $key ]['plugins'][ $k ] = trim( ( $k + 1 ) . '. ' . str_replace( 'for WooCommerce', '', $plugin->name ) );
                        }

                        $wpc_keys[ $wpc_key ] = $keys[ $key ];
                    }
                }

                $result['keys'] = $wpc_keys;

                return $result;
            }

            return [ 'success' => false ];
        }

        function wpc_rest_route_unverify_callback( $data ) {
            $result = [ 'success' => false ];
            $key    = sanitize_key( $data['key'] ?? '' );

            if ( ! empty( $key ) ) {
                $secret_key = substr( $key, 0, 10 ) . substr( $key, strlen( $key ) - 4, 4 );
                $keys       = (array) get_option( 'wpc_update_keys', [] );

                if ( ! empty( $secret_key ) && ! empty( $keys[ $secret_key ] ) ) {
                    unset( $keys[ $secret_key ] );
                    update_option( 'wpc_update_keys', $keys );
                    $result['success'] = true;
                    $result['key']     = $secret_key;
                }
            }

            return $result;
        }

        function admin_enqueue_scripts( $hook ) {
            // JS + nonce on all admin pages (dismiss notice needs it everywhere)
            wp_enqueue_script( 'wpc-premium', WPC_PREMIUM_URI . 'js/premium.js', [ 'jquery' ], WPC_PREMIUM_VERSION, true );
            wp_localize_script( 'wpc-premium', 'wpc_premium_vars', [
                    'nonce' => wp_create_nonce( 'wpc_premium' ),
            ] );

            // CSS only on the License Keys page
            if ( str_contains( $hook, 'wpclever-keys' ) ) {
                wp_enqueue_style( 'wpc-premium', WPC_PREMIUM_URI . 'css/premium.css', [], WPC_PREMIUM_VERSION );
            }
        }

        function admin_menu() {
            add_submenu_page( 'wpclever', 'WPC License Keys', 'License Keys', 'manage_options', 'wpclever-keys', [
                    $this,
                    'admin_menu_content'
            ], 1 );
        }

        /**
         * Add License Keys item to the shared nav.
         */
        function add_nav_item( $items ) {
            $items['keys'] = [
                    'url'   => admin_url( 'admin.php?page=wpclever-keys' ),
                    'label' => 'License Keys',
            ];

            return $items;
        }

        function admin_menu_content() {
            ?>
            <div class="wpclever_page wpclever_update_keys_page wrap">
                <?php
                if ( method_exists( 'WPCleverDashboard', 'render_header' ) ) {
                    WPCleverDashboard::render_header( 'keys' );
                } else {
                    echo '<h1>WPClever | License Keys</h1>';
                }
                ?>

                <?php if ( self::is_dev_site( get_bloginfo( 'url' ) ) ) { ?>
                    <div class="wpc-card">
                        <div class="wpclever_is_dev_site"
                             style="padding: 6px 12px; background-color: #fff3cd; border: 1px dashed #ffeeba; border-radius: 4px;">
                            It appears you are building your website on a development
                            domain <strong><?php echo esc_html( get_bloginfo( 'url' ) ); ?></strong>. You don't need to
                            verify a
                            license for this development domain, only for your production website.
                        </div>
                    </div>
                <?php } else { ?>
                    <div class="wpc-card">
                        <h2 class="wpc-card-title">
                            <span class="dashicons dashicons-admin-network"></span> Enter Your License Keys
                        </h2>
                        <p>
                            Enter your License Key to verify the license you're using and turn on the update
                            notification. Verified licenses can enjoy unlimited update release and get the latest
                            plugin update directly on our website.
                        </p>
                        <p class="wpc-card-desc">
                            Please check the purchase receipt to find your Receipt ID (old-type invoice) or License Key
                            (new-type invoice) to verify your license(s). You can also access the
                            <a href="https://wpclever.net/my-account/" target="_blank">Membership page</a> to get the
                            license key and enter it below for the verification of each purchase attached to your
                            account.
                        </p>
                        <div class="wpclever_update_keys_form">
                            <input type="hidden" name="wpc_update_site" id="wpc_update_site"
                                   value="<?php echo esc_attr( get_bloginfo( 'url' ) ); ?>"/>
                            <input type="hidden" name="wpc_update_email" id="wpc_update_email"
                                   value="<?php echo esc_attr( get_bloginfo( 'admin_email' ) ); ?>"/>
                            <input type="text" name="wpc_update_key" id="wpc_update_key" class="regular-text"
                                   placeholder="Receipt ID or License Key"/>
                            <input type="button" value="Verify" id="wpc_add_update_key"/>
                        </div>
                    </div>

                    <div class="wpc-card">
                        <h2 class="wpc-card-title">
                            <span class="dashicons dashicons-yes-alt"></span> Verified Keys
                        </h2>
                        <?php
                        $keys = (array) get_option( 'wpc_update_keys', [] );

                        if ( ! empty( $keys ) ) {
                            ?>
                            <table class="wpc_update_keys">
                                <thead>
                                <tr>
                                    <th>Key</th>
                                    <th>Allowed plugins</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                foreach ( array_reverse( $keys ) as $key => $val ) {
                                    echo '<tr>';
                                    echo '<td>' . esc_html( substr( $key, 0, 10 ) . '...' . substr( $key, strlen( $key ) - 4, 4 ) ) . '</td>';
                                    echo '<td>';
                                    echo '<ul>';

                                    foreach ( $val['plugins'] as $plugin ) {
                                        echo '<li>' . esc_html( $plugin->name ) . '</li>';
                                    }

                                    echo '</ul>';
                                    echo '</td>';
                                    echo '<td><div class="wpc-premium-validated">Validated on: ' . esc_html( $val['date'] ?? '' ) . '</div><div class="wpc-premium-support-expires">Support expires: ' . ( isset( $val['date'] ) ? esc_html( wp_date( 'Y-m-d H:i:s', strtotime( '+1 year', strtotime( $val['date'] ) ) ) ) : '' ) . ' ' . ( time() > strtotime( '+1 year', strtotime( $val['date'] ) ) ? '(expired)' : '' ) . '</div></td>';
                                    echo '<td><a href="#" class="wpc_remove_key" data-key="' . esc_attr( $key ) . '">remove</a></td>';
                                    echo '</tr>';
                                }
                                ?>
                                </tbody>
                            </table>
                        <?php } else {
                            echo '<p class="wpc-card-desc">Have no keys was verified. Please add your first one!</p>';
                        } ?>
                    </div>
                <?php } ?>
            </div>
            <?php
        }

        /**
         * Check if the given site URL is a development or local environment.
         *
         * @param string $site The site URL to check.
         *
         * @return bool
         */
        function is_dev_site( $site ) {
            $site = strtolower( trim( $site ) );
            $host = wp_parse_url( $site, PHP_URL_HOST ) ?: $site;
            $path = wp_parse_url( $site, PHP_URL_PATH ) ?: '';

            // Exact host matches and localhost variants
            $dev_hosts = [
                    'localhost',
                    '127.0.0.1',
                    '0.0.0.0',
                    '::1',
            ];

            if ( in_array( $host, $dev_hosts, true ) ) {
                return apply_filters( 'wpc_is_dev_site', true, $site );
            }

            // Private IP ranges (192.168.x.x, 10.x.x.x, 172.16-31.x.x)
            if ( filter_var( $host, FILTER_VALIDATE_IP ) && ! filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
                return apply_filters( 'wpc_is_dev_site', true, $site );
            }

            // Dev TLDs and host suffixes
            $dev_suffixes = [ '.local', '.test', '.ddev.site', '.lndo.site', '.ngrok.io', '.ngrok-free.app' ];

            foreach ( $dev_suffixes as $suffix ) {
                if ( str_ends_with( $host, $suffix ) ) {
                    return apply_filters( 'wpc_is_dev_site', true, $site );
                }
            }

            // Subdomain prefixes (dev.example.com, staging.example.com, etc.)
            $dev_prefixes = [ 'dev.', 'test.', 'beta.', 'staging.', 'stage.', 'local.', 'demo.' ];

            foreach ( $dev_prefixes as $prefix ) {
                if ( str_starts_with( $host, $prefix ) ) {
                    return apply_filters( 'wpc_is_dev_site', true, $site );
                }
            }

            // Host contains "staging" (covers sub.staging.example.com)
            if ( str_contains( $host, 'staging' ) ) {
                return apply_filters( 'wpc_is_dev_site', true, $site );
            }

            // Path-based checks — match exact segments only to avoid false positives
            $dev_path_segments = [ '/dev/', '/test/', '/beta/', '/staging/' ];

            // Also check if path ends with the segment (no trailing slash)
            $dev_path_ends = [ '/dev', '/test', '/beta', '/staging' ];

            foreach ( $dev_path_segments as $segment ) {
                if ( str_contains( $path, $segment ) ) {
                    return apply_filters( 'wpc_is_dev_site', true, $site );
                }
            }

            foreach ( $dev_path_ends as $end ) {
                if ( str_ends_with( $path, $end ) ) {
                    return apply_filters( 'wpc_is_dev_site', true, $site );
                }
            }

            return apply_filters( 'wpc_is_dev_site', false, $site );
        }

        function check_update_key() {
            check_ajax_referer( 'wpc_premium', 'nonce' );

            if ( ! empty( $_POST['key'] ) ) {
                $key      = sanitize_key( wp_unslash( $_POST['key'] ) );
                $site     = sanitize_url( wp_unslash( $_POST['site'] ?? '' ) );
                $email    = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
                $response = wp_remote_post( 'https://wpclever.net/wp-json/update/v2/verify/', [
                        'headers' => [ 'Accept' => 'application/json' ],
                        'body'    => [
                                'key'   => $key,
                                'site'  => $site,
                                'email' => $email
                        ],
                ] );
                $data     = wp_remote_retrieve_body( $response );

                if ( ! empty( $data ) ) {
                    $result = json_decode( $data );

                    if ( property_exists( $result, 'id' ) && $result->id && property_exists( $result, 'plugins' ) ) {
                        // add keys
                        $keys                = (array) get_option( 'wpc_update_keys', [] );
                        $secret_key          = substr( $key, 0, 10 ) . substr( $key, strlen( $key ) - 4, 4 );
                        $keys[ $secret_key ] = [
                                'id'      => $result->id,
                                'plugins' => $result->plugins,
                                'date'    => property_exists( $result, 'date' ) ? $result->date : ''
                        ];

                        update_option( 'wpc_update_keys', $keys );
                    }
                }
            }

            wp_die();
        }

        function remove_key() {
            check_ajax_referer( 'wpc_premium', 'nonce' );

            if ( ! empty( $_POST['key'] ) ) {
                $key  = sanitize_key( wp_unslash( $_POST['key'] ) );
                $keys = (array) get_option( 'wpc_update_keys', [] );
                unset( $keys[ $key ] );

                update_option( 'wpc_update_keys', $keys );
            }

            wp_die();
        }

        function dismiss_notice() {
            check_ajax_referer( 'wpc_premium', 'nonce' );

            if ( ! empty( $_POST['key'] ) ) {
                $key = sanitize_key( wp_unslash( $_POST['key'] ) );

                update_option( 'wpc_dismiss_notice_' . $key, time() );
            }

            wp_die();
        }

        /**
         * Get the update key for a given product ID.
         *
         * @param int|string $id Product ID.
         *
         * @return string|false
         */
        public static function get_update_key( $id = '' ) {
            if ( ! empty( $id ) ) {
                $keys = (array) get_option( 'wpc_update_keys', [] );

                if ( empty( $keys ) ) {
                    return false;
                }

                foreach ( array_reverse( $keys ) as $key ) {
                    if ( is_array( $key['plugins'] ) && ! empty( $key['plugins'] ) ) {
                        foreach ( $key['plugins'] as $plugin ) {
                            if ( $plugin->id == $id ) {
                                return $plugin->key;
                            }
                        }
                    }
                }
            }

            return false;
        }
    }

    new WPCleverPremium();
}
