<?php
/**
 * WPC Premium Registry — Manages registered premium plugins.
 *
 * @package WPC_Premium
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WPC_Premium_Registry' ) ) {
	class WPC_Premium_Registry {
		private static $instance;
		private $plugins = [];

		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Register a premium plugin.
		 *
		 * @param array $args {
		 *
		 * @type int $id Product ID on wpclever.net (e.g. 60737).
		 * @type string $file Main plugin file path (__FILE__).
		 * @type string $dir Plugin directory path.
		 * @type string $name Display name for admin notices.
		 * @type string $prefix Unique prefix (e.g. "wpcpr").
		 * }
		 */
		public function register( $args ) {
			$defaults = [
				'id'     => 0,
				'file'   => '',
				'dir'    => '',
				'name'   => '',
				'prefix' => '',
			];

			$args = wp_parse_args( $args, $defaults );

			if ( empty( $args['prefix'] ) || empty( $args['id'] ) ) {
				return;
			}

			$this->plugins[ $args['prefix'] ] = $args;
		}

		/**
		 * Get all registered plugins.
		 *
		 * @return array
		 */
		public function get_plugins() {
			return $this->plugins;
		}

		/**
		 * Get a specific plugin by prefix.
		 *
		 * @param string $prefix
		 *
		 * @return array|null
		 */
		public function get_plugin( $prefix ) {
			return $this->plugins[ $prefix ] ?? null;
		}
	}
}
