<?php
/**
 * WPC Premium — Single entry point for the shared premium module.
 *
 * Usage in any WPC plugin:
 *   require_once __DIR__ . '/includes/wpc-premium/wpc-premium.php';
 *   wpc_premium_register( [
 *       'id'     => 60737,
 *       'file'   => __FILE__,
 *       'dir'    => plugin_dir_path( __FILE__ ),
 *       'name'   => 'WPC Smart Points & Rewards',
 *       'prefix' => 'wpcpr',
 *   ] );
 *
 * @package WPC_Premium
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

// Version guard: only load the highest version when multiple plugins ship wpc-premium.
$wpc_premium_this_version = '1.0.0';

if ( defined( 'WPC_PREMIUM_VERSION' ) ) {
	if ( version_compare( WPC_PREMIUM_VERSION, $wpc_premium_this_version, '>=' ) ) {
		return; // A newer or equal version is already loaded.
	}
}

define( 'WPC_PREMIUM_VERSION', $wpc_premium_this_version );
define( 'WPC_PREMIUM_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPC_PREMIUM_URI', plugin_dir_url( __FILE__ ) );

// Load dependencies
include_once WPC_PREMIUM_DIR . 'wpc-checker.php';
require_once WPC_PREMIUM_DIR . 'class-wpc-premium-registry.php';
require_once WPC_PREMIUM_DIR . 'class-wpc-premium.php';

/**
 * Shortcut function for plugins to register with the premium module.
 *
 * @param array $args See WPC_Premium_Registry::register().
 */
if ( ! function_exists( 'wpc_premium_register' ) ) {
	function wpc_premium_register( $args ) {
		WPC_Premium_Registry::instance()->register( $args );

		// Fallback: if the old WPCleverPremium (without registry support) is loaded,
		// register update checker manually for this plugin.
		if ( ! method_exists( 'WPCleverPremium', 'register_update_checkers' ) ) {
			$args = wp_parse_args( $args, [ 'id' => 0, 'file' => '', 'dir' => '', 'name' => '', 'prefix' => '' ] );

			if ( $args['id'] && $args['file'] ) {
				add_action( 'init', function () use ( $args ) {
					$id   = $args['id'];
					$file = $args['file'];
					$dir  = $args['dir'];

					if ( $key = wpc_get_update_key( $id ) ) {
						PucFactory::buildUpdateChecker( 'https://api.wpclever.net/update/' . $key . '.json', $file, plugin_basename( $dir ) );
					} else {
						PucFactory::buildUpdateChecker( 'https://api.wpclever.net/update/' . $id . '.json', $file, plugin_basename( $dir ) );
					}
				}, 99 );

				// Fallback admin notice
				add_action( 'admin_notices', function () use ( $args ) {
					if ( apply_filters( 'wpc_dismiss_notices', false ) ) {
						return;
					}

					$dismiss_key = 'wpc_dismiss_notice_' . $args['prefix'] . '_update';

					if ( get_option( $dismiss_key ) ) {
						return;
					}

					if ( ! wpc_get_update_key( $args['id'] ) ) {
						echo '<div data-dismissible="' . esc_attr( $args['prefix'] ) . '_update" class="wpc-notice notice notice-warning is-dismissible"><p>Please verify <a href="' . esc_url( admin_url( 'admin.php?page=wpclever-keys' ) ) . '">License Key</a> of <strong>' . esc_html( $args['name'] ) . '</strong> to enjoy unlimited update release and get the latest plugin update directly on the website backend.</p></div>';
					}
				}, 99 );
			}
		}
	}
}

/**
 * Get the update key for a given product ID.
 */
if ( ! function_exists( 'wpc_get_update_key' ) ) {
	function wpc_get_update_key( $id = '' ) {
		return WPCleverPremium::get_update_key( $id );
	}
}
