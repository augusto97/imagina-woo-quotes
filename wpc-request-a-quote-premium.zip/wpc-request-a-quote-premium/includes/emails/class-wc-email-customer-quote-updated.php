<?php
/**
 * Class WPCRQ_Email_Customer_Quote_Updated
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPCRQ_Email_Customer_Quote_Updated', false ) ) :

	/**
	 * Customer Quote Updated Email.
	 *
	 * An email sent to the customer when the admin sends an updated quote.
	 */
	class WPCRQ_Email_Customer_Quote_Updated extends WC_Email {

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->id             = 'customer_quote_updated';
			$this->title          = __( 'Quote Updated (Customer)', 'wpc-request-a-quote' );
			$this->description    = __( 'This email is sent to customers when an admin sends an updated quote.', 'wpc-request-a-quote' );
			$this->template_html  = 'emails/customer-quote-updated.php';
			$this->template_plain = 'emails/plain/customer-quote-updated.php';
			$this->template_base  = WPCRQ_DIR . 'templates/';
			$this->placeholders   = [
				'{site_title}'   => $this->get_blogname(),
				'{quote_number}' => '',
			];
			$this->customer_email = true;

			// Triggers for this email.
			add_action( 'wpcrq_send_updated_quote_email', [ $this, 'trigger' ], 10, 1 );

			// Call parent constructor.
			parent::__construct();
		}

		/**
		 * Default content to show below main email content.
		 *
		 * @return string
		 */
		public function get_default_additional_content() {
			return __( 'Please review the updated quote and let us know if you accept it.', 'wpc-request-a-quote' );
		}

		/**
		 * Trigger the sending of this email.
		 *
		 * @param int $order_id The order ID.
		 */
		public function trigger( $order_id ) {
			$this->setup_locale();

			$order = wc_get_order( $order_id );

			if ( is_a( $order, 'WC_Order' ) ) {
				$this->object                         = $order;
				$this->placeholders['{quote_number}'] = $this->object->get_order_number();
				$this->recipient                      = $this->object->get_billing_email();

				if ( $this->is_enabled() && $this->get_recipient() ) {
					$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
				}
			}

			$this->restore_locale();
		}

		/**
		 * Get email subject.
		 *
		 * @return string
		 */
		public function get_default_subject() {
			return __( 'Your quote request #{quote_number} has been updated', 'wpc-request-a-quote' );
		}

		/**
		 * Get email heading.
		 *
		 * @return string
		 */
		public function get_default_heading() {
			return __( 'Quote Updated', 'wpc-request-a-quote' );
		}

		/**
		 * Get content html.
		 *
		 * @return string
		 */
		public function get_content_html() {
			WPCRQ_Emails::$customer_email_type = 'quote_updated';
			$content                           = wc_get_template_html(
				$this->template_html,
				[
					'order'              => $this->object,
					'email_heading'      => $this->get_heading(),
					'additional_content' => $this->get_additional_content(),
					'sent_to_admin'      => false,
					'plain_text'         => false,
					'email'              => $this,
				],
				'',
				$this->template_base
			);
			WPCRQ_Emails::$customer_email_type = 'none';

			return $content;
		}

		/**
		 * Get content plain.
		 *
		 * @return string
		 */
		public function get_content_plain() {
			WPCRQ_Emails::$customer_email_type = 'quote_updated';
			$content                           = wc_get_template_html(
				$this->template_plain,
				[
					'order'              => $this->object,
					'email_heading'      => $this->get_heading(),
					'additional_content' => $this->get_additional_content(),
					'sent_to_admin'      => false,
					'plain_text'         => true,
					'email'              => $this,
				],
				'',
				$this->template_base
			);
			WPCRQ_Emails::$customer_email_type = 'none';

			return $content;
		}

		/**
		 * Initialise settings form fields.
		 */
		public function init_form_fields() {
			/* translators: %s: list of available placeholder strings */
			$placeholder_text = sprintf( __( 'Available placeholders: %s', 'wpc-request-a-quote' ), '<code>' . implode( '</code>, <code>', array_keys( $this->placeholders ) ) . '</code>' );

			$this->form_fields = [
				'enabled'            => [
					'title'   => __( 'Enable/Disable', 'wpc-request-a-quote' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable this email notification', 'wpc-request-a-quote' ),
					'default' => 'yes',
				],
				'subject'            => [
					'title'       => __( 'Subject', 'wpc-request-a-quote' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_subject(),
					'default'     => '',
				],
				'heading'            => [
					'title'       => __( 'Email heading', 'wpc-request-a-quote' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_heading(),
					'default'     => '',
				],
				'additional_content' => [
					'title'       => __( 'Additional content', 'wpc-request-a-quote' ),
					'description' => __( 'Text to appear below the main email content.', 'wpc-request-a-quote' ) . ' ' . $placeholder_text,
					'css'         => 'width:400px; height: 75px;',
					'placeholder' => __( 'N/A', 'wpc-request-a-quote' ),
					'type'        => 'textarea',
					'default'     => $this->get_default_additional_content(),
					'desc_tip'    => true,
				],
				'email_type'         => [
					'title'       => __( 'Email type', 'wpc-request-a-quote' ),
					'type'        => 'select',
					'description' => __( 'Choose which format of email to send.', 'wpc-request-a-quote' ),
					'default'     => 'html',
					'class'       => 'email_type wc-enhanced-select',
					'options'     => $this->get_email_type_options(),
					'desc_tip'    => true,
				],
			];
		}
	}

endif;
