<?php
/**
 * Class WPCRQ_Email_New_Quote_Request
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WPCRQ_Email_New_Quote_Request', false ) ) :

	/**
	 * New Quote Request Email.
	 *
	 * An email sent to the admin when a new quote is created.
	 */
	class WPCRQ_Email_New_Quote_Request extends WC_Email {

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->id             = 'new_quote_request';
			$this->title          = __( 'New Quote Request', 'wpc-request-a-quote' );
			$this->description    = __( 'New quote request emails are sent to chosen recipient(s) when a new quote is received.', 'wpc-request-a-quote' );
			$this->template_html  = 'emails/admin-new-quote-request.php';
			$this->template_plain = 'emails/plain/admin-new-quote-request.php';
			$this->placeholders   = [
				'{site_title}'   => $this->get_blogname(),
				'{quote_number}' => '',
			];

			// Triggers for this email.
			add_action( 'wpcrq_new_quote_request', [ $this, 'trigger' ], 10, 2 );

			// Call parent constructor.
			parent::__construct();

			// Other settings.
			$this->recipient = $this->get_option( 'recipient', get_option( 'admin_email' ) );
		}

		/**
		 * Default content to show below main email content.
		 *
		 * @return string
		 * @since 3.7.0
		 */
		public function get_default_additional_content() {
			return __( 'Congratulations on the new quote request.', 'wpc-request-a-quote' );
		}

		/**
		 * Trigger the sending of this email.
		 *
		 * @param int $order_id The order ID.
		 * @param WC_Order|false $order Order object.
		 */
		public function trigger( $order_id, $order = false ) {
			$this->setup_locale();

			if ( $order_id && ! is_a( $order, 'WC_Order' ) ) {
				$order = wc_get_order( $order_id );
			}

			if ( is_a( $order, 'WC_Order' ) ) {
				$this->object                         = $order;
				$this->placeholders['{quote_number}'] = $this->object->get_order_number();

				if ( $this->is_enabled() && $this->get_recipient() ) {
					$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
				}
			}

			$this->restore_locale();
		}

		/**
		 * Get email subject.
		 *
		 * @return string
		 */
		public function get_default_subject() {
			return __( '[{site_title}]: New quote request #{quote_number}', 'wpc-request-a-quote' );
		}

		/**
		 * Get email heading.
		 *
		 * @return string
		 */
		public function get_default_heading() {
			return __( 'New Quote Request: #{quote_number}', 'wpc-request-a-quote' );
		}

		/**
		 * Get content html.
		 *
		 * @return string
		 */
		public function get_content_html() {
			// We can fallback to the default order email template.
			return wc_get_template_html(
				'emails/admin-new-order.php',
				[
					'order'              => $this->object,
					'email_heading'      => $this->get_heading(),
					'additional_content' => $this->get_additional_content(),
					'sent_to_admin'      => true,
					'plain_text'         => false,
					'email'              => $this,
				]
			);
		}

		/**
		 * Get content plain.
		 *
		 * @return string
		 */
		public function get_content_plain() {
			return wc_get_template_html(
				'emails/plain/admin-new-order.php',
				[
					'order'              => $this->object,
					'email_heading'      => $this->get_heading(),
					'additional_content' => $this->get_additional_content(),
					'sent_to_admin'      => true,
					'plain_text'         => true,
					'email'              => $this,
				]
			);
		}

		/**
		 * Initialise settings form fields.
		 */
		public function init_form_fields() {
			/* translators: %s: list of available placeholder strings */
			$placeholder_text = sprintf( __( 'Available placeholders: %s', 'wpc-request-a-quote' ), '<code>' . implode( '</code>, <code>', array_keys( $this->placeholders ) ) . '</code>' );

			$this->form_fields = [
				'enabled'            => [
					'title'   => __( 'Enable/Disable', 'wpc-request-a-quote' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable this email notification', 'wpc-request-a-quote' ),
					'default' => 'yes',
				],
				'recipient'          => [
					'title'       => __( 'Recipient(s)', 'wpc-request-a-quote' ),
					'type'        => 'text',
					/* translators: %s: admin email */
					'description' => sprintf( __( 'Enter recipients (comma separated) for this email. Defaults to %s.', 'wpc-request-a-quote' ), '<code>' . esc_attr( get_option( 'admin_email' ) ) . '</code>' ),
					'placeholder' => '',
					'default'     => '',
					'desc_tip'    => true,
				],
				'subject'            => [
					'title'       => __( 'Subject', 'wpc-request-a-quote' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_subject(),
					'default'     => '',
				],
				'heading'            => [
					'title'       => __( 'Email heading', 'wpc-request-a-quote' ),
					'type'        => 'text',
					'desc_tip'    => true,
					'description' => $placeholder_text,
					'placeholder' => $this->get_default_heading(),
					'default'     => '',
				],
				'additional_content' => [
					'title'       => __( 'Additional content', 'wpc-request-a-quote' ),
					'description' => __( 'Text to appear below the main email content.', 'wpc-request-a-quote' ) . ' ' . $placeholder_text,
					'css'         => 'width:400px; height: 75px;',
					'placeholder' => __( 'N/A', 'wpc-request-a-quote' ),
					'type'        => 'textarea',
					'default'     => $this->get_default_additional_content(),
					'desc_tip'    => true,
				],
				'email_type'         => [
					'title'       => __( 'Email type', 'wpc-request-a-quote' ),
					'type'        => 'select',
					'description' => __( 'Choose which format of email to send.', 'wpc-request-a-quote' ),
					'default'     => 'html',
					'class'       => 'email_type wc-enhanced-select',
					'options'     => $this->get_email_type_options(),
					'desc_tip'    => true,
				],
			];
		}
	}

endif;
