<?php
/**
 * WC_Gateway_Request_A_Quote Class
 */
defined( 'ABSPATH' ) || exit;

class WC_Gateway_Request_A_Quote extends WC_Payment_Gateway {
	/**
	 * @var string
	 */
	public $instructions;


	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {
		$this->id                 = 'request_a_quote';
		$this->icon               = apply_filters( 'woocommerce_request_a_quote_icon', '' );
		$this->has_fields         = false;
		$this->method_title       = __( 'Request a Quote', 'wpc-request-a-quote' );
		$this->method_description = __( 'Allows customers to request a quote instead of paying immediately. No upfront payment is required.', 'wpc-request-a-quote' );

		// Declare WooCommerce Blocks support so Checkout Block can render this gateway.
		$this->supports = [
			'products',
		];

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables
		$this->title        = $this->get_option( 'title' );
		$this->description  = $this->get_option( 'description' );
		$this->instructions = $this->get_option( 'instructions', $this->description );

		// Actions
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
	}

	/**
	 * Initialize Gateway Settings Form Fields
	 */
	public function init_form_fields() {
		$this->form_fields = apply_filters( 'wpcrq_gateway_form_fields', [
			'enabled'      => [
				'title'   => __( 'Enable/Disable', 'wpc-request-a-quote' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Request a Quote', 'wpc-request-a-quote' ),
				'default' => 'no',
			],
			'title'        => [
				'title'       => __( 'Title', 'wpc-request-a-quote' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'wpc-request-a-quote' ),
				'default'     => __( 'Request a Quote', 'wpc-request-a-quote' ),
				'desc_tip'    => true,
			],
			'description'  => [
				'title'       => __( 'Description', 'wpc-request-a-quote' ),
				'type'        => 'textarea',
				'description' => __( 'Payment method description that the customer will see on your checkout.', 'wpc-request-a-quote' ),
				'default'     => __( 'Your order will be marked as a quote request. No upfront payment is required at this time. An administrator will review your order and send you a formal quote.', 'wpc-request-a-quote' ),
				'desc_tip'    => true,
			],
			'instructions' => [
				'title'       => __( 'Instructions', 'wpc-request-a-quote' ),
				'type'        => 'textarea',
				'description' => __( 'Instructions that will be added to the thank you page and emails.', 'wpc-request-a-quote' ),
				'default'     => '',
				'desc_tip'    => true,
			],
		] );
	}

	/**
	 * Check if the gateway is available for use.
	 *
	 * @return bool
	 */
	public function is_available() {
		if ( is_checkout_pay_page() ) {
			return false;
		}

		if ( class_exists( 'WPCRQ_Frontend' ) && ! WPCRQ_Frontend::can_request_quote() ) {
			return false;
		}

		return parent::is_available();
	}

	/**
	 * Process the payment and return the result
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );

		// Mark as Quote Request
		$order->update_status( 'quote-request', __( 'Order placed via Request a Quote payment method.', 'wpc-request-a-quote' ) );

		// Add custom meta to identify this as a quote if needed
		$order->update_meta_data( '_wpcrq_is_quote', 'yes' );
		$order->save();

		// Reduce stock levels
		// wc_reduce_stock_levels( $order_id ); // Usually quotes don't reduce stock until accepted.

		// Trigger emails
		WC()->mailer();
		do_action( 'wpcrq_new_quote_request', $order_id );

		// Log for statistics
		WPCRQ_Statistics::log_event( $order_id, 'received' );

		// Remove cart
		WC()->cart->empty_cart();

		// Return thank you page redirect
		return [
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		];
	}
}
