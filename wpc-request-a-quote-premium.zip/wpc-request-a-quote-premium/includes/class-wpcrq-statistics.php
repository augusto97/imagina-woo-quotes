<?php
/**
 * Quote Statistics for Admin
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Statistics {
	public static function init() {
		self::create_table();
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_scripts' ] );
		add_action( 'woocommerce_order_status_changed', [ __CLASS__, 'log_status_change' ], 10, 4 );
	}

	public static function create_table() {
		global $wpdb;
		$table_name      = $wpdb->prefix . 'wpc_quote_stats';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			order_id bigint(20) NOT NULL,
			event_type varchar(20) NOT NULL,
			created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
			PRIMARY KEY  (id),
			KEY order_id (order_id),
			KEY event_type (event_type)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	public static function log_event( $order_id, $event_type ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'wpc_quote_stats';

		// Check if this event already exists for this order to avoid duplicates (except maybe 'reviewed'?)
		// For simplicity, let's allow multiple 'reviewed' but others only once.
		if ( 'reviewed' !== $event_type ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time duplicate check, not suitable for caching.
			$exists = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM %i WHERE order_id = %d AND event_type = %s",
				$table_name,
				$order_id,
				$event_type
			) );
			if ( $exists ) {
				return;
			}
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom statistics table insert.
		$wpdb->insert(
			$table_name,
			[
				'order_id'   => $order_id,
				'event_type' => $event_type,
				'created_at' => current_time( 'mysql' ),
			]
		);
	}

	public static function log_status_change( $order_id, $old_status, $new_status, $order ) {
		if ( ! $order->get_meta( '_wpcrq_is_quote' ) ) {
			return;
		}

		if ( in_array( $new_status, [ 'processing', 'completed' ] ) ) {
			self::log_event( $order_id, 'paid' );
		}
	}

	public static function enqueue_scripts( $hook ) {
		if ( ! str_contains( $hook, 'wpclever-wpcrq' ) ) {
			return;
		}

		wp_enqueue_style( 'wpcrq-admin-stats', WPCRQ_URI . 'assets/css/admin-stats.css', [], WPCRQ_VERSION );
		wp_enqueue_script( 'chart-js', WPCRQ_URI . 'assets/js/chart.min.js', [], '4.4.1', true );
	}

	public static function get_stats( $days = 7, $start_date = '', $end_date = '' ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'wpc_quote_stats';

		if ( $start_date && $end_date ) {
			// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Real-time statistics, must not be cached.
			$results = $wpdb->get_results( $wpdb->prepare( 'SELECT event_type, COUNT(*) as count FROM %i WHERE created_at BETWEEN %s AND %s GROUP BY event_type', $table_name, $start_date . ' 00:00:00', $end_date . ' 23:59:59' ), OBJECT_K );
		} elseif ( $days > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Real-time statistics.
			$results = $wpdb->get_results( $wpdb->prepare( 'SELECT event_type, COUNT(*) as count FROM %i WHERE created_at >= %s GROUP BY event_type', $table_name, gmdate( 'Y-m-d H:i:s', strtotime( '-' . $days . ' days' ) ) ), OBJECT_K );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Real-time statistics.
			$results = $wpdb->get_results( $wpdb->prepare( 'SELECT event_type, COUNT(*) as count FROM %i GROUP BY event_type', $table_name ), OBJECT_K );
		}

		$stats = [
			'received' => isset( $results['received'] ) ? (int) $results['received']->count : 0,
			'reviewed' => isset( $results['reviewed'] ) ? (int) $results['reviewed']->count : 0,
			'accepted' => isset( $results['accepted'] ) ? (int) $results['accepted']->count : 0,
			'rejected' => isset( $results['rejected'] ) ? (int) $results['rejected']->count : 0,
			'paid'     => isset( $results['paid'] ) ? (int) $results['paid']->count : 0,
		];

		return $stats;
	}

	public static function get_chart_data( $days = 7, $start_date = '', $end_date = '' ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'wpc_quote_stats';

		if ( $start_date && $end_date ) {
			$start = new DateTime( $start_date );
			$end   = new DateTime( $end_date );
			// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Real-time chart data.
			$results = $wpdb->get_results( $wpdb->prepare( 'SELECT DATE(created_at) as date, event_type, COUNT(*) as count FROM %i WHERE created_at BETWEEN %s AND %s GROUP BY DATE(created_at), event_type ORDER BY date ASC', $table_name, $start_date . ' 00:00:00', $end_date . ' 23:59:59' ) );
		} else {
			$days  = $days ?: 7;
			$start = new DateTime( '-' . $days . ' days' );
			$end   = new DateTime();
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Real-time chart data.
			$results = $wpdb->get_results( $wpdb->prepare( 'SELECT DATE(created_at) as date, event_type, COUNT(*) as count FROM %i WHERE created_at >= %s GROUP BY DATE(created_at), event_type ORDER BY date ASC', $table_name, gmdate( 'Y-m-d H:i:s', strtotime( '-' . $days . ' days' ) ) ) );
		}

		$data     = [];
		$interval = new DateInterval( 'P1D' );
		$period   = new DatePeriod( $start, $interval, $end->modify( '+1 day' ) );

		$types    = [
			'received' => [ 'label' => __( 'Received', 'wpc-request-a-quote' ), 'color' => '#3498db' ],
			'accepted' => [ 'label' => __( 'Accepted', 'wpc-request-a-quote' ), 'color' => '#2ecc71' ],
			'paid'     => [ 'label' => __( 'Paid', 'wpc-request-a-quote' ), 'color' => '#9b59b6' ]
		];
		$labels   = [];
		$datasets = [];

		foreach ( $types as $key => $config ) {
			$datasets[ $key ] = [
				'label'           => $config['label'],
				'borderColor'     => $config['color'],
				'backgroundColor' => $config['color'] . '22', // Transparent
				'data'            => [],
				'fill'            => true,
				'tension'         => 0.4
			];
		}

		$raw_data = [];
		foreach ( $results as $row ) {
			$raw_data[ $row->date ][ $row->event_type ] = (int) $row->count;
		}

		foreach ( $period as $dt ) {
			$date_str = $dt->format( 'Y-m-d' );
			$labels[] = $dt->format( 'M d' );
			foreach ( $types as $key => $config ) {
				$datasets[ $key ]['data'][] = $raw_data[ $date_str ][ $key ] ?? 0;
			}
		}

		return [
			'labels'   => $labels,
			'datasets' => array_values( $datasets ),
		];
	}
}

WPCRQ_Statistics::init();
