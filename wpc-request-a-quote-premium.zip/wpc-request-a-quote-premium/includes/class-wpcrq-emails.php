<?php
/**
 * Register custom WooCommerce emails
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Emails {
	public static $customer_email_type = 'none';

	public static function init() {
		add_filter( 'woocommerce_email_classes', [ __CLASS__, 'add_email_classes' ] );

		// Hide totals in emails
		add_filter( 'woocommerce_get_order_item_totals', [ __CLASS__, 'hide_totals_in_email' ], 10, 3 );

		// Hide item subtotal in emails
		add_filter( 'woocommerce_order_item_get_subtotal', [ __CLASS__, 'hide_item_subtotal_in_email' ], 10, 3 );

		// Add CSS to hide columns in HTML emails
		add_filter( 'woocommerce_email_styles', [ __CLASS__, 'add_email_styles' ], 10, 2 );
	}

	public static function hide_totals_in_email( $total_rows, $order, $tax_display = null ) {
		if ( 'none' === self::$customer_email_type ) {
			return $total_rows;
		}

		if ( ! is_a( $order, 'WC_Order' ) || 'yes' !== $order->get_meta( '_wpcrq_is_quote' ) ) {
			return $total_rows;
		}

		if ( 'quote_request' === self::$customer_email_type ) {
			$show_price = WPCRQ_Settings::get_setting( 'quote_request_price', 'no' );
			if ( 'yes' !== $show_price ) {
				return [];
			}
		} elseif ( 'quote_updated' === self::$customer_email_type ) {
			$show_price = WPCRQ_Settings::get_setting( 'quote_updated_price', 'no' );
			if ( 'no' === $show_price ) {
				return [];
			}
		}

		return $total_rows;
	}

	public static function hide_item_subtotal_in_email( $subtotal, $item, $order = null ) {
		if ( 'none' === self::$customer_email_type ) {
			return $subtotal;
		}

		if ( ! $order && is_callable( [ $item, 'get_order' ] ) ) {
			$order = $item->get_order();
		}

		if ( ! is_a( $order, 'WC_Order' ) || 'yes' !== $order->get_meta( '_wpcrq_is_quote' ) ) {
			return $subtotal;
		}

		if ( 'quote_request' === self::$customer_email_type ) {
			$show_price = WPCRQ_Settings::get_setting( 'quote_request_price', 'no' );
			if ( 'yes' !== $show_price ) {
				return '';
			}
		} elseif ( 'quote_updated' === self::$customer_email_type ) {
			$show_price = WPCRQ_Settings::get_setting( 'quote_updated_price', 'no' );
			if ( 'no' === $show_price ) {
				return '';
			}
		}

		return $subtotal;
	}

	/**
	 * Render order details table, conditionally hiding the Price column.
	 */
	public static function render_order_details( $order, $sent_to_admin, $plain_text, $email ) {
		$hide_all_pricing = false;
		$hide_column_only = false;

		if ( 'quote_request' === self::$customer_email_type ) {
			if ( 'yes' !== WPCRQ_Settings::get_setting( 'quote_request_price', 'no' ) ) {
				$hide_all_pricing = true;
			}
		} elseif ( 'quote_updated' === self::$customer_email_type ) {
			$setting = WPCRQ_Settings::get_setting( 'quote_updated_price', 'no' );
			if ( 'no' === $setting ) {
				$hide_all_pricing = true;
			} elseif ( 'price_column_only' === $setting ) {
				$hide_column_only = true;
			}
		}

		ob_start();
		do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );
		$output = ob_get_clean();

		if ( 'none' !== self::$customer_email_type ) {
			if ( $hide_all_pricing || $hide_column_only ) {
				if ( $plain_text ) {
					if ( $hide_all_pricing ) {
						// Aggressive strip (any row with a pipe)
						$output = preg_replace( '/^(.*\s*)\|\s*[^|\n]+\s*$/m', '$1', $output );
					} else {
						// Selective strip (only rows with 3+ columns, i.e., 2+ pipes)
						$output = preg_replace( '/^(.*\|.*)\|\s*[^|\n]+\s*$/m', '$1', $output );
					}
				} else {
					// For HTML, we use CSS for "price_column_only" and regex only for "hide_all_pricing"
					if ( $hide_all_pricing ) {
						// $1 = from <tr until end of penultimate td/th
						// $2 = penultimate tag (h or d)
						// $3 = last tag (h or d)
						$output = preg_replace( '/(<tr[^>]*>(?:(?!<tr).)*?<t(h|d)[^>]*>.*?<\/t\2>(?:(?!<tr).)*)<t(h|d)[^>]*>.*?<\/t\3>\s*<\/tr>/is', '$1</tr>', $output );
					} else {
						// Wrap in class to support CSS hiding
						$output = '<div class="wpcrq-hide-price-col">' . $output . '</div>';
					}
				}
			}
		}

		echo wp_kses_post( $output );
	}

	public static function add_email_styles( $css, $email ) {
		if ( ! in_array( $email->id, [ 'customer_quote', 'customer_quote_updated' ], true ) ) {
			return $css;
		}

		$hide_pricing     = false;
		$hide_column_only = false;

		if ( 'customer_quote' === $email->id ) {
			if ( 'yes' !== WPCRQ_Settings::get_setting( 'quote_request_price', 'no' ) ) {
				$hide_pricing = true;
			}
		} else {
			$setting = WPCRQ_Settings::get_setting( 'quote_updated_price', 'no' );
			if ( 'no' === $setting ) {
				$hide_pricing = true;
			} elseif ( 'price_column_only' === $setting ) {
				$hide_column_only = true;
			}
		}

		if ( $hide_column_only ) {
			// CSS targeting specific elements for hiding Price column while keeping totals.
			// This is only applied to HTML emails via the wrapper class.
			$css .= '
				.wpcrq-hide-price-col thead th:last-child:not(:first-child),
				.wpcrq-hide-price-col tbody td:last-child:not(:first-child),
				.wpcrq-hide-price-col .order_item td:last-child:not(:first-child) {
					display: none !important;
				}
			';
		}

		return $css;
	}

	public static function add_email_classes( $email_classes ) {
		require_once WPCRQ_DIR . 'includes/emails/class-wc-email-new-quote.php';
		require_once WPCRQ_DIR . 'includes/emails/class-wc-email-customer-quote.php';
		require_once WPCRQ_DIR . 'includes/emails/class-wc-email-customer-quote-updated.php';

		$email_classes['WPCRQ_Email_New_Quote_Request']      = new WPCRQ_Email_New_Quote_Request();
		$email_classes['WPCRQ_Email_Customer_Quote_Request'] = new WPCRQ_Email_Customer_Quote_Request();
		$email_classes['WPCRQ_Email_Customer_Quote_Updated'] = new WPCRQ_Email_Customer_Quote_Updated();

		return $email_classes;
	}
}

WPCRQ_Emails::init();
