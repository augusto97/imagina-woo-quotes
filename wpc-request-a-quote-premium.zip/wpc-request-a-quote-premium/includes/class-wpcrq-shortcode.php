<?php
/**
 * Shortcode for Quote Page
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Shortcode {
	public static function init() {
		add_shortcode( 'wpcrq_quote_page', [ __CLASS__, 'quote_page_shortcode' ] );
		add_shortcode( 'wpcrq_quote_count', [ __CLASS__, 'quote_count_shortcode' ] );
		add_shortcode( 'wpcrq_quote_btn', [ __CLASS__, 'quote_btn_shortcode' ] );
		// Ensure AJAX for submission
		add_action( 'wp_ajax_wpcrq_submit_quote', [ __CLASS__, 'ajax_submit_quote' ] );
		add_action( 'wp_ajax_nopriv_wpcrq_submit_quote', [ __CLASS__, 'ajax_submit_quote' ] );
	}

	public static function quote_page_shortcode( $atts ) {
		$allowed_roles = WPCRQ_Settings::get_setting( 'allowed_roles', [ 'all' ] );
		if ( ! is_array( $allowed_roles ) ) {
			$allowed_roles = [ $allowed_roles ];
		}

		$can_request_quote = false;

		if ( in_array( 'all', $allowed_roles, true ) ) {
			$can_request_quote = true;
		} else {
			if ( is_user_logged_in() ) {
				$user       = wp_get_current_user();
				$user_roles = (array) $user->roles;

				if ( in_array( 'logged_in', $allowed_roles, true ) ) {
					$can_request_quote = true;
				} else {
					foreach ( $user_roles as $role ) {
						if ( in_array( $role, $allowed_roles, true ) ) {
							$can_request_quote = true;
							break;
						}
					}
				}
			} else {
				if ( in_array( 'guest', $allowed_roles, true ) ) {
					$can_request_quote = true;
				}
			}
		}

		ob_start();
		echo '<div id="wpcrq-quote-page" class="wpcrq-quote-page-wrapper">';

		if ( ! $can_request_quote ) {
			echo '<div class="woocommerce-info wpcrq-info">' . esc_html( WPCRQ_Localization::get_text( 'no_permission' ) ) . '</div>';
			echo '</div>';

			return ob_get_clean();
		}

		$items = WPCRQ_Session::get_quote_items();

		if ( empty( $items ) ) {
			echo '<div class="wpcrq-empty-quote">';
			echo esc_html( WPCRQ_Localization::get_text( 'your_quote_empty' ) );
			echo ' <a class="button" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">' . esc_html( WPCRQ_Localization::get_text( 'return_to_shop' ) ) . '</a>';
			echo '</div>';
			echo '</div>';

			return ob_get_clean();
		}

		// Include the template for the quote page (List + Form)
		$template_path = WPCRQ_DIR . 'templates/quote-page.php';

		if ( file_exists( $template_path ) ) {
			include $template_path;
		}

		echo '</div>';

		return ob_get_clean();
	}

	public static function ajax_submit_quote() {
		check_ajax_referer( 'wpcrq-nonce', 'nonce' );

		$items = WPCRQ_Session::get_quote_items();

		if ( empty( $items ) ) {
			wp_send_json_error( [ 'message' => WPCRQ_Localization::get_text( 'quote_list_empty' ) ] );
		}

		// Validate minimums and maximums
		$min_qty   = absint( WPCRQ_Settings::get_setting( 'min_qty', 0 ) );
		$max_qty   = absint( WPCRQ_Settings::get_setting( 'max_qty', 0 ) );
		$total_qty = WPCRQ_Session::get_total_quantity();

		if ( $min_qty > 0 && $total_qty < $min_qty ) {
			wp_send_json_error( [ 'message' => sprintf( WPCRQ_Localization::get_text( 'min_qty_error' ), $min_qty ) ] );
		}
		if ( $max_qty > 0 && $total_qty > $max_qty ) {
			wp_send_json_error( [ 'message' => sprintf( WPCRQ_Localization::get_text( 'max_qty_error' ), $max_qty ) ] );
		}

		// Sanitize form data
		$first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ) : '';
		$last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ) : '';
		$email      = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ) : '';
		$phone      = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ) : '';
		$message    = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ) : '';

		$max_length = WPCRQ_Settings::get_setting( 'max_message_length', 255 );
		if ( $max_length !== '' && $max_length > 0 && mb_strlen( $message ) > $max_length ) {
			wp_send_json_error( [ 'message' => sprintf( WPCRQ_Localization::get_text( 'message_too_long' ), $max_length ) ] );
		}

		if ( empty( $first_name ) || empty( $email ) ) {
			wp_send_json_error( [ 'message' => WPCRQ_Localization::get_text( 'first_name_email_required' ) ] );
		}

		if ( ! is_email( $email ) ) {
			wp_send_json_error( [ 'message' => WPCRQ_Localization::get_text( 'invalid_email' ) ] );
		}

		// Create a mock order or a real WC_Order with custom status
		$order = wc_create_order( [
			'status' => 'quote-request',
		] );

		if ( is_wp_error( $order ) ) {
			wp_send_json_error( [ 'message' => apply_filters( 'wpcrq_quote_requested_failed_message', WPCRQ_Localization::get_text( 'failed_to_create' ) ) ] );
		}

		$order->update_meta_data( '_wpcrq_is_quote', 'yes' );

		if ( is_user_logged_in() ) {
			$order->set_customer_id( get_current_user_id() );
		}

		$order->set_billing_first_name( $first_name );
		$order->set_billing_last_name( $last_name );
		$order->set_billing_email( $email );
		$order->set_billing_phone( $phone );
		$order->set_customer_note( $message );

		// Add items to order
		foreach ( $items as $item_key => $item ) {
			$product = wc_get_product( $item['variation_id'] ? $item['variation_id'] : $item['product_id'] );
			if ( $product ) {
				$order->add_product( $product, $item['quantity'], [
					'variation' => $item['variation'],
				] );
			}
		}

		$order->calculate_totals();
		$order->save();

		// Empty session
		WPCRQ_Session::empty_quote();

		// Make sure WC mailer is loaded so our custom emails have attached their hooks
		WC()->mailer();

		// Trigger emails
		do_action( 'wpcrq_new_quote_request', $order->get_id() );

		// Log for statistics
		WPCRQ_Statistics::log_event( $order->get_id(), 'received' );

		wp_send_json_success( [
			'message'  => apply_filters( 'wpcrq_quote_requested_success_message', WPCRQ_Localization::get_text( 'quote_requested_success' ), $order->get_id() ),
			'order_id' => $order->get_id(),
		] );
	}

	public static function quote_count_shortcode() {
		$items = WPCRQ_Session::get_quote_items();
		$count = 0;
		foreach ( $items as $item ) {
			$count += $item['quantity'];
		}

		return '<span class="wpcrq-quote-count">' . absint( $count ) . '</span>';
	}

	public static function quote_btn_shortcode( $atts ) {
		$atts = shortcode_atts( [
			'product_id' => 0,
			'context'    => 'single',
		], $atts, 'wpcrq_quote_btn' );

		return WPCRQ_Frontend::get_button_html( absint( $atts['product_id'] ), sanitize_text_field( $atts['context'] ) );
	}
}

WPCRQ_Shortcode::init();
