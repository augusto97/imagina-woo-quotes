<?php
/**
 * Session management for Quote items
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Session {
	public static function init() {
		// Initialize session if not started
		add_action( 'init', [ __CLASS__, 'maybe_start_session' ] );

		// AJAX for adding item
		add_action( 'wp_ajax_wpcrq_add_to_quote', [ __CLASS__, 'ajax_add_to_quote' ] );
		add_action( 'wp_ajax_nopriv_wpcrq_add_to_quote', [ __CLASS__, 'ajax_add_to_quote' ] );

		// AJAX for removing item
		add_action( 'wp_ajax_wpcrq_remove_from_quote', [ __CLASS__, 'ajax_remove_from_quote' ] );
		add_action( 'wp_ajax_nopriv_wpcrq_remove_from_quote', [ __CLASS__, 'ajax_remove_from_quote' ] );

		// AJAX for getting cart count (optional)
		add_action( 'wp_ajax_wpcrq_get_quote_count', [ __CLASS__, 'ajax_get_quote_count' ] );
		add_action( 'wp_ajax_nopriv_wpcrq_get_quote_count', [ __CLASS__, 'ajax_get_quote_count' ] );

		// AJAX for refreshing fragments
		add_action( 'wp_ajax_wpcrq_get_refreshed_fragments', [ __CLASS__, 'ajax_get_refreshed_fragments' ] );
		add_action( 'wp_ajax_nopriv_wpcrq_get_refreshed_fragments', [ __CLASS__, 'ajax_get_refreshed_fragments' ] );

		// AJAX for updating quote
		add_action( 'wp_ajax_wpcrq_update_quote', [ __CLASS__, 'ajax_update_quote' ] );
		add_action( 'wp_ajax_nopriv_wpcrq_update_quote', [ __CLASS__, 'ajax_update_quote' ] );

		// AJAX for updating quote
	}

	public static function maybe_start_session() {
		if ( isset( WC()->session ) && ! WC()->session->has_session() ) {
			WC()->session->set_customer_session_cookie( true );
		}
	}

	public static function get_quote_items() {
		if ( ! isset( WC()->session ) ) {
			return [];
		}

		return WC()->session->get( 'wpcrq_quote', [] );
	}

	public static function set_quote_items( $items ) {
		if ( isset( WC()->session ) ) {
			WC()->session->set( 'wpcrq_quote', $items );
		}
	}

	public static function is_in_quote( $product_id ) {
		$items = self::get_quote_items();
		if ( empty( $items ) ) {
			return false;
		}

		foreach ( $items as $item ) {
			if ( (int) $item['product_id'] === (int) $product_id ) {
				return true;
			}
		}

		return false;
	}

	public static function get_total_quantity() {
		$items = self::get_quote_items();
		$total = 0;
		if ( ! empty( $items ) ) {
			foreach ( $items as $item ) {
				$total += $item['quantity'];
			}
		}

		return $total;
	}

	public static function get_item_product_ids() {
		$items = self::get_quote_items();
		$ids   = [];
		foreach ( $items as $item ) {
			$ids[] = (int) $item['product_id'];
		}

		return array_unique( $ids );
	}

	public static function empty_quote() {
		self::set_quote_items( [] );
	}

	public static function generate_item_key( $product_id, $variation_id = 0, $variation = [] ) {
		$id_parts = [ $product_id ];

		if ( $variation_id && $variation ) {
			$id_parts[] = $variation_id;
			$id_parts[] = serialize( $variation );
		}

		return md5( implode( '_', $id_parts ) );
	}

	public static function ajax_add_to_quote() {
		check_ajax_referer( 'wpcrq-nonce', 'nonce' );

		$product_id   = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ?? '' ) ) : 0;
		$quantity     = isset( $_POST['quantity'] ) ? absint( wp_unslash( $_POST['quantity'] ?? '' ) ) : 1;
		$variation_id = isset( $_POST['variation_id'] ) ? absint( wp_unslash( $_POST['variation_id'] ?? '' ) ) : 0;
		$variation    = isset( $_POST['variation'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['variation'] ) ) : [];

		if ( ! $product_id ) {
			wp_send_json_error( [ 'message' => __( 'Invalid product.', 'wpc-request-a-quote' ) ] );
		}

		if ( ! WPCRQ_Frontend::can_request_quote( $product_id ) ) {
			wp_send_json_error( [ 'message' => __( 'You do not have permission to request a quote for this product.', 'wpc-request-a-quote' ) ] );
		}

		$items    = self::get_quote_items();
		$item_key = self::generate_item_key( $product_id, $variation_id, $variation );

		$individual_mode = WPCRQ_Settings::get_setting( 'individual_quote', 'no' ) === 'yes';

		if ( $individual_mode ) {
			if ( ! isset( $items[ $item_key ] ) ) {
				$items = [];
			}
		}

		if ( isset( $items[ $item_key ] ) ) {
			$items[ $item_key ]['quantity'] += $quantity;
		} else {
			$items[ $item_key ] = [
				'product_id'   => $product_id,
				'variation_id' => $variation_id,
				'variation'    => $variation,
				'quantity'     => $quantity,
			];
		}

		self::set_quote_items( $items );

		$fragments = self::get_fragments();

		wp_send_json_success( [
			'message'   => WPCRQ_Localization::get_text( 'product_added' ),
			'fragments' => $fragments,
			'cart_hash' => md5( json_encode( $items ) ),
			'item_ids'  => self::get_item_product_ids(),
		] );
	}

	public static function ajax_remove_from_quote() {
		check_ajax_referer( 'wpcrq-nonce', 'nonce' );

		$item_key = isset( $_POST['item_key'] ) ? sanitize_text_field( wp_unslash( $_POST['item_key'] ?? '' ) ) : '';

		if ( ! $item_key ) {
			wp_send_json_error();
		}

		$items = self::get_quote_items();

		if ( isset( $items[ $item_key ] ) ) {
			unset( $items[ $item_key ] );
			self::set_quote_items( $items );
		}

		$fragments = self::get_fragments();

		wp_send_json_success( [
			'message'   => WPCRQ_Localization::get_text( 'product_removed' ),
			'fragments' => $fragments,
			'cart_hash' => md5( json_encode( $items ) ),
			'item_ids'  => self::get_item_product_ids(),
		] );
	}

	public static function ajax_get_quote_count() {
		$items = self::get_quote_items();
		$count = 0;
		foreach ( $items as $item ) {
			$count += $item['quantity'];
		}
		wp_send_json_success( [ 'count' => $count ] );
	}

	public static function get_fragments() {
		$items = self::get_quote_items();
		$count = 0;
		foreach ( $items as $item ) {
			$count += $item['quantity'];
		}

		$fragments = [
			'.wpcrq-quote-count' => '<span class="wpcrq-quote-count">' . $count . '</span>',
		];

		if ( class_exists( 'WPCRQ_Shortcode' ) ) {
			$fragments['#wpcrq-quote-page'] = WPCRQ_Shortcode::quote_page_shortcode( [] );
		}

		return apply_filters( 'wpcrq_fragments', $fragments );
	}

	public static function ajax_get_refreshed_fragments() {
		$items     = self::get_quote_items();
		$fragments = self::get_fragments();

		wp_send_json_success( [
			'fragments' => $fragments,
			'cart_hash' => md5( json_encode( $items ) ),
			'item_ids'  => self::get_item_product_ids(),
		] );
	}

	public static function ajax_update_quote() {
		check_ajax_referer( 'wpcrq-nonce', 'nonce' );

		if ( isset( $_POST['wpcrq_qty'] ) && is_array( $_POST['wpcrq_qty'] ) ) {
			$items      = self::get_quote_items();
			$changed    = false;
			$temp_items = $items;

			foreach ( array_map( 'absint', wp_unslash( $_POST['wpcrq_qty'] ?? [] ) ) as $item_key => $quantity ) {
				$quantity = absint( $quantity );

				if ( isset( $temp_items[ $item_key ] ) ) {
					if ( $quantity === 0 ) {
						unset( $temp_items[ $item_key ] );
						$changed = true;
					} elseif ( $temp_items[ $item_key ]['quantity'] !== $quantity ) {
						$temp_items[ $item_key ]['quantity'] = $quantity;
						$changed                             = true;
					}
				}
			}

			if ( $changed ) {
				self::set_quote_items( $temp_items );
			}
		}

		$fragments = self::get_fragments();

		wp_send_json_success( [
			'message'   => WPCRQ_Localization::get_text( 'quote_list_updated' ),
			'fragments' => $fragments,
			'cart_hash' => md5( json_encode( self::get_quote_items() ) ),
			'item_ids'  => self::get_item_product_ids(),
		] );
	}

}

WPCRQ_Session::init();
