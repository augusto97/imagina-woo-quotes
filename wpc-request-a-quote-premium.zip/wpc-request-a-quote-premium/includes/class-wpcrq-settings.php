<?php
/**
 * Settings for WPC Request a Quote
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Settings {
    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'add_menu' ] );
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
        add_filter( 'pre_update_option', [ __CLASS__, 'last_saved' ], 10, 2 );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_scripts' ] );
        add_filter( 'plugin_action_links', [ __CLASS__, 'action_links' ], 10, 2 );
        add_filter( 'plugin_row_meta', [ __CLASS__, 'row_meta' ], 10, 2 );
    }

    public static function get_setting( $name, $default = '' ) {
        $settings = get_option( 'wpcrq_settings', [] );

        if ( isset( $settings[ $name ] ) ) {
            return $settings[ $name ];
        }

        // Fallback to legacy individual options for migration
        $legacy_value = get_option( 'wpcrq_' . $name, null );

        if ( null !== $legacy_value ) {
            // Migrate to new array on first read/save attempt?
            // For now, just return the legacy value.
            // The next save in settings page will consolidate it.
            return $legacy_value;
        }

        return $default;
    }

    public static function add_menu() {
        add_submenu_page(
                'wpclever',
                esc_html__( 'WPC Request a Quote', 'wpc-request-a-quote' ),
                esc_html__( 'Request a Quote', 'wpc-request-a-quote' ),
                'manage_options',
                'wpclever-wpcrq',
                [ __CLASS__, 'admin_menu_content' ]
        );
    }

    public static function enqueue_scripts( $hook ) {
        if ( ! str_contains( $hook, 'wpclever-wpcrq' ) ) {
            return;
        }

        wp_enqueue_style( 'woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', [], WC_VERSION );
        wp_enqueue_script( 'selectWoo' );
        wp_enqueue_script( 'wc-enhanced-select' );
    }

    public static function register_settings() {
        register_setting( 'wpcrq_settings', 'wpcrq_settings', [
                'sanitize_callback' => [ __CLASS__, 'sanitize_settings' ],
        ] );
        register_setting( 'wpcrq_localization', 'wpcrq_localization', [
                'sanitize_callback' => [ __CLASS__, 'sanitize_localization' ],
        ] );
    }

    /**
     * Per-field sanitization schema for wpcrq_settings.
     *
     * Each entry maps a field key to its sanitization type:
     *  - 'key'      → sanitize_key()          (enum / slug values)
     *  - 'absint'   → absint()                 (IDs and non-negative integers)
     *  - 'bool'     → 'yes'|'' checkbox value
     *  - 'key[]'    → array of sanitize_key()  (multi-select)
     *  - 'absint[]' → array of absint()         (multi-select numeric IDs)
     *
     * Only fields declared here are persisted; any unknown input is discarded.
     *
     * @return array<string, string>
     */
    private static function settings_schema(): array {
        return [
            // General
                'individual_quote'        => 'key',
                'allowed_roles'           => 'key[]',
                'allowed_categories'      => 'absint[]',
                'allowed_types'           => 'key[]',
                'enable_payment_gateway'  => 'key',

            // Button
                'button_position_archive' => 'key',
                'button_position_single'  => 'key',
                'after_add_action'        => 'key',
                'hide_price'              => 'bool',

            // Page & Form
                'quote_page_id'           => 'absint',
                'form_layout'             => 'key',
                'show_subtotal'           => 'key',
                'min_qty'                 => 'absint',
                'max_qty'                 => 'absint',
                'max_message_length'      => 'absint',

            // Emails
                'quote_request_price'     => 'key',
                'quote_updated_price'     => 'key',
        ];
    }

    /**
     * Sanitize settings option values.
     *
     * Uses a strict per-field schema so each value is sanitized with the most
     * appropriate WordPress function. Unknown keys are silently discarded.
     *
     * @param array $input Raw input from the settings form.
     *
     * @return array Sanitized values.
     */
    public static function sanitize_settings( $input ) {
        if ( ! is_array( $input ) ) {
            return [];
        }

        $sanitized = [];
        $schema    = self::settings_schema();

        foreach ( $schema as $key => $type ) {
            // Skip fields that were not submitted (e.g. unchecked checkboxes).
            if ( ! isset( $input[ $key ] ) ) {
                // Unchecked checkboxes are simply absent – store empty string.
                if ( 'bool' === $type ) {
                    $sanitized[ $key ] = '';
                }
                continue;
            }

            $raw = $input[ $key ];

            switch ( $type ) {
                case 'absint':
                    $sanitized[ $key ] = absint( $raw );
                    break;

                case 'absint[]':
                    $sanitized[ $key ] = is_array( $raw )
                            ? array_values( array_map( 'absint', $raw ) )
                            : [ absint( $raw ) ];
                    break;

                case 'key':
                    $sanitized[ $key ] = sanitize_key( $raw );
                    break;

                case 'key[]':
                    $sanitized[ $key ] = is_array( $raw )
                            ? array_values( array_map( 'sanitize_key', $raw ) )
                            : [ sanitize_key( $raw ) ];
                    break;

                case 'bool':
                    // Checkbox: only accept literal 'yes'.
                    $sanitized[ $key ] = ( 'yes' === $raw ) ? 'yes' : '';
                    break;

                default:
                    $sanitized[ $key ] = sanitize_text_field( $raw );
                    break;
            }
        }

        return $sanitized;
    }

    /**
     * Sanitize localization option values.
     *
     * All localization strings are user-visible UI labels and are safely
     * sanitized with sanitize_text_field().
     *
     * @param array $input Raw input from the localization form.
     *
     * @return array Sanitized values.
     */
    public static function sanitize_localization( $input ) {
        if ( ! is_array( $input ) ) {
            return [];
        }

        $sanitized = [];

        foreach ( $input as $key => $value ) {
            $sanitized[ sanitize_key( $key ) ] = sanitize_text_field( $value );
        }

        return $sanitized;
    }

    public static function last_saved( $value, $option ) {
        if ( $option == 'wpcrq_settings' || $option == 'wpcrq_localization' ) {
            $value['_last_saved']    = current_time( 'timestamp' );
            $value['_last_saved_by'] = get_current_user_id();
        }

        return $value;
    }

    public static function admin_menu_content() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Tab navigation param, not form data.
        $active_tab   = sanitize_key( wp_unslash( $_GET['tab'] ?? 'settings' ) );
        $pages        = get_pages();
        $page_options = [ 0 => esc_html__( '-- Select a page --', 'wpc-request-a-quote' ) ];
        foreach ( $pages as $page ) {
            $page_options[ $page->ID ] = $page->post_title;
        }

        ?>
        <div class="wpclever_settings_page wrap">
            <div class="wpclever_settings_page_header">
                <a class="wpclever_settings_page_header_logo" href="https://wpclever.net/"
                   target="_blank" title="Visit wpclever.net"></a>
                <div class="wpclever_settings_page_header_text">
                    <div class="wpclever_settings_page_title"><?php echo esc_html__( 'WPC Request a Quote', 'wpc-request-a-quote' ) . ' ' . esc_html( WPCRQ_VERSION ) . ' ' . ( defined( 'WPCRQ_PREMIUM' ) ? '<span class="premium" style="display: none">' . esc_html__( 'Premium', 'wpc-request-a-quote' ) . '</span>' : '' ); ?></div>
                    <div class="wpclever_settings_page_desc about-text">
                        <p>
                            <?php printf( /* translators: stars */ esc_html__( 'Thank you for using our plugin! If you are satisfied, please reward it a full five-star %s rating.', 'wpc-request-a-quote' ), '<span style="color:#ffb900">&#9733;&#9733;&#9733;&#9733;&#9733;</span>' ); ?>
                            <br/>
                            <a href="<?php echo esc_url( WPCRQ_REVIEWS ); ?>"
                               target="_blank"><?php esc_html_e( 'Reviews', 'wpc-request-a-quote' ); ?></a> |
                            <a href="<?php echo esc_url( WPCRQ_CHANGELOG ); ?>"
                               target="_blank"><?php esc_html_e( 'Changelog', 'wpc-request-a-quote' ); ?></a>
                            |
                            <a href="<?php echo esc_url( WPCRQ_DISCUSSION ); ?>"
                               target="_blank"><?php esc_html_e( 'Discussion', 'wpc-request-a-quote' ); ?></a>
                        </p>
                    </div>
                </div>
            </div>
            <h2></h2>
            <?php
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- WordPress settings API redirect param.
            if ( isset( $_GET['settings-updated'] ) && sanitize_text_field( wp_unslash( $_GET['settings-updated'] ) ) ) { ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php esc_html_e( 'Settings updated.', 'wpc-request-a-quote' ); ?></p>
                </div>
            <?php } ?>
            <div class="wpclever_settings_page_nav">
                <h2 class="nav-tab-wrapper">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpclever-wpcrq&tab=settings' ) ); ?>"
                       class="<?php echo esc_attr( $active_tab === 'settings' ? 'nav-tab nav-tab-active' : 'nav-tab' ); ?>">
                        <?php esc_html_e( 'Settings', 'wpc-request-a-quote' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpclever-wpcrq&tab=localization' ) ); ?>"
                       class="<?php echo esc_attr( $active_tab === 'localization' ? 'nav-tab nav-tab-active' : 'nav-tab' ); ?>">
                        <?php esc_html_e( 'Localization', 'wpc-request-a-quote' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpclever-wpcrq&tab=statistics' ) ); ?>"
                       class="<?php echo esc_attr( $active_tab === 'statistics' ? 'nav-tab nav-tab-active' : 'nav-tab' ); ?>">
                        <?php esc_html_e( 'Statistics', 'wpc-request-a-quote' ); ?>
                    </a>
                    <!--
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpclever-wpcrq&tab=premium' ) ); ?>"
                       class="<?php echo esc_attr( $active_tab === 'premium' ? 'nav-tab nav-tab-active' : 'nav-tab' ); ?>"
                       style="color: #c9356e">
                        <?php esc_html_e( 'Premium Version', 'wpc-request-a-quote' ); ?>
                    </a>
                    -->
                    <a href="<?php echo esc_url( WPCRQ_SUPPORT ); ?>" class="nav-tab" target="_blank">
                        <?php esc_html_e( 'Support', 'wpc-request-a-quote' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpclever-kit' ) ); ?>"
                       class="nav-tab">
                        <?php esc_html_e( 'Essential Kit', 'wpc-request-a-quote' ); ?>
                    </a>
                </h2>
            </div>
            <div class="wpclever_settings_page_content">
                <?php if ( $active_tab === 'settings' ) { ?>
                    <form method="post" action="options.php">
                        <table class="form-table">
                            <tr class="heading">
                                <th colspan="2">
                                    <?php esc_html_e( 'General', 'wpc-request-a-quote' ); ?>
                                </th>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_individual_quote"><?php esc_html_e( 'Individual Quote', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[individual_quote]" id="wpcrq_settings_individual_quote"
                                            style="width: 300px;">
                                        <option value="no" <?php selected( self::get_setting( 'individual_quote', 'no' ), 'no' ); ?>>
                                            <?php esc_html_e( 'No', 'wpc-request-a-quote' ); ?></option>
                                        <option value="yes" <?php selected( self::get_setting( 'individual_quote', 'no' ), 'yes' ); ?>>
                                            <?php esc_html_e( 'Yes', 'wpc-request-a-quote' ); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'If enabled, only one product can be added to the quote list. Adding a new product will remove existing ones.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_allowed_roles"><?php esc_html_e( 'Allowed Roles', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <?php
                                    $allowed_roles = self::get_setting( 'allowed_roles', [ 'all' ] );
                                    if ( empty( $allowed_roles ) || ! is_array( $allowed_roles ) ) {
                                        $allowed_roles = [ 'all' ];
                                    }

                                    if ( in_array( 'all', $allowed_roles, true ) ) {
                                        $allowed_roles = [ 'all' ];
                                    }

                                    global $wp_roles;
                                    $roles = $wp_roles->roles;
                                    ?>
                                    <select class="wc-enhanced-select" multiple="multiple" style="width: 300px;"
                                            id="wpcrq_settings_allowed_roles" name="wpcrq_settings[allowed_roles][]"
                                            data-placeholder="<?php esc_attr_e( 'Select user roles&hellip;', 'wpc-request-a-quote' ); ?>">
                                        <option value="all" <?php selected( in_array( 'all', $allowed_roles, true ) ); ?>><?php esc_html_e( 'All', 'wpc-request-a-quote' ); ?></option>
                                        <option value="user_logged_in" <?php selected( in_array( 'user_logged_in', $allowed_roles, true ) ); ?>>
                                            <?php esc_html_e( 'User (logged in)', 'wpc-request-a-quote' ); ?></option>
                                        <option value="guest" <?php selected( in_array( 'guest', $allowed_roles, true ) ); ?>>
                                            <?php esc_html_e( 'Guest (not logged in)', 'wpc-request-a-quote' ); ?></option>
                                        <?php foreach ( $roles as $role_key => $role_data ): ?>
                                            <option value="<?php echo esc_attr( $role_key ); ?>" <?php selected( in_array( $role_key, $allowed_roles, true ) ); ?>>
                                                <?php echo esc_html( $role_data['name'] ); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Select which user roles can request a quote.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_allowed_categories"><?php esc_html_e( 'Allowed Categories', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <?php
                                    $allowed_categories = self::get_setting( 'allowed_categories', [] );
                                    if ( ! is_array( $allowed_categories ) ) {
                                        $allowed_categories = [ $allowed_categories ];
                                    }
                                    ?>
                                    <select class="wc-enhanced-select" multiple="multiple" style="width: 300px;"
                                            id="wpcrq_settings_allowed_categories"
                                            name="wpcrq_settings[allowed_categories][]"
                                            data-placeholder="<?php esc_attr_e( 'Select categories&hellip;', 'wpc-request-a-quote' ); ?>">
                                        <?php
                                        $product_categories = get_terms( [
                                                'taxonomy'   => 'product_cat',
                                                'hide_empty' => false,
                                        ] );

                                        if ( ! is_wp_error( $product_categories ) && ! empty( $product_categories ) ) {
                                            foreach ( $product_categories as $category ) {
                                                echo '<option value="' . esc_attr( $category->term_id ) . '" ' . selected( in_array( $category->term_id, $allowed_categories ), true, false ) . '>' . esc_html( wp_strip_all_tags( $category->name ) ) . '</option>';
                                            }
                                        }
                                        ?>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Select which product categories can be requested for a quote. Leave blank to allow all categories.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_allowed_types"><?php esc_html_e( 'Allowed Product Types', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <?php
                                    $allowed_types = self::get_setting( 'allowed_types', [ 'all' ] );
                                    if ( empty( $allowed_types ) || ! is_array( $allowed_types ) ) {
                                        $allowed_types = [ 'all' ];
                                    }

                                    if ( in_array( 'all', $allowed_types, true ) ) {
                                        $allowed_types = [ 'all' ];
                                    }

                                    if ( function_exists( 'wc_get_product_types' ) ) {
                                        $product_types = wc_get_product_types();
                                    } else {
                                        $product_types = [
                                                'simple'   => __( 'Simple product', 'wpc-request-a-quote' ),
                                                'grouped'  => __( 'Grouped product', 'wpc-request-a-quote' ),
                                                'external' => __( 'External/Affiliate product', 'wpc-request-a-quote' ),
                                                'variable' => __( 'Variable product', 'wpc-request-a-quote' ),
                                        ];
                                    }
                                    ?>
                                    <select class="wc-enhanced-select" multiple="multiple" style="width: 300px;"
                                            id="wpcrq_settings_allowed_types" name="wpcrq_settings[allowed_types][]"
                                            data-placeholder="<?php esc_attr_e( 'Select product types&hellip;', 'wpc-request-a-quote' ); ?>">
                                        <option value="all" <?php selected( in_array( 'all', $allowed_types, true ) ); ?>><?php esc_html_e( 'All', 'wpc-request-a-quote' ); ?></option>
                                        <?php foreach ( $product_types as $type_name => $type_label ): ?>
                                            <option value="<?php echo esc_attr( $type_name ); ?>" <?php selected( in_array( $type_name, $allowed_types, true ) ); ?>>
                                                <?php echo esc_html( $type_label ); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Select which product types can be requested for a quote.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_enable_payment_gateway"><?php esc_html_e( 'Enable payment gateway', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[enable_payment_gateway]"
                                            id="wpcrq_settings_enable_payment_gateway"
                                            style="width: 300px;">
                                        <option value="no" <?php selected( self::get_setting( 'enable_payment_gateway', 'no' ), 'no' ); ?>><?php esc_html_e( 'No', 'wpc-request-a-quote' ); ?></option>
                                        <option value="yes" <?php selected( self::get_setting( 'enable_payment_gateway', 'no' ), 'yes' ); ?>><?php esc_html_e( 'Yes', 'wpc-request-a-quote' ); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php printf(
                                        /* translators: %s: WooCommerce Payments settings page link */
                                                esc_html__( 'Enable "Request a Quote" as a payment method at checkout. After enabling this, please go to %s to enable it.', 'wpc-request-a-quote' ),
                                                '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) . '">WooCommerce > Settings > Payments</a>'
                                        ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr class="heading">
                                <th colspan="2">
                                    <?php esc_html_e( 'Button', 'wpc-request-a-quote' ); ?>
                                </th>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_button_position_archive"><?php esc_html_e( 'Button position (Archive)', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[button_position_archive]"
                                            id="wpcrq_settings_button_position_archive"
                                            style="width: 300px;">
                                        <option value="before" <?php selected( self::get_setting( 'button_position_archive', 'after' ), 'before' ); ?>><?php esc_html_e( 'Before Add to Cart button', 'wpc-request-a-quote' ); ?>
                                        </option>
                                        <option value="after" <?php selected( self::get_setting( 'button_position_archive', 'after' ), 'after' ); ?>><?php esc_html_e( 'After Add to Cart button', 'wpc-request-a-quote' ); ?>
                                        </option>
                                        <option value="replace" <?php selected( self::get_setting( 'button_position_archive', 'after' ), 'replace' ); ?>><?php esc_html_e( 'Replace Add to Cart button', 'wpc-request-a-quote' ); ?>
                                        </option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Position of the "Add to Quote" button on the shop and archive pages.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_button_position_single"><?php esc_html_e( 'Button position (Single)', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[button_position_single]"
                                            id="wpcrq_settings_button_position_single"
                                            style="width: 300px;">
                                        <option value="before" <?php selected( self::get_setting( 'button_position_single', 'after' ), 'before' ); ?>><?php esc_html_e( 'Before Add to Cart button', 'wpc-request-a-quote' ); ?>
                                        </option>
                                        <option value="after" <?php selected( self::get_setting( 'button_position_single', 'after' ), 'after' ); ?>><?php esc_html_e( 'After Add to Cart button', 'wpc-request-a-quote' ); ?>
                                        </option>
                                        <option value="replace" <?php selected( self::get_setting( 'button_position_single', 'after' ), 'replace' ); ?>><?php esc_html_e( 'Replace Add to Cart button', 'wpc-request-a-quote' ); ?>
                                        </option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Position of the "Add to Quote" button on the single product page.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_after_add_action"><?php esc_html_e( 'After clicking Add to Quote', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[after_add_action]" id="wpcrq_settings_after_add_action"
                                            style="width: 300px;">
                                        <option value="none" <?php selected( self::get_setting( 'after_add_action', 'browse' ), 'none' ); ?>>
                                            <?php esc_html_e( 'None', 'wpc-request-a-quote' ); ?></option>
                                        <option value="browse" <?php selected( self::get_setting( 'after_add_action', 'browse' ), 'browse' ); ?>>
                                            <?php esc_html_e( 'Show "Browse quote list" link', 'wpc-request-a-quote' ); ?></option>
                                        <option value="redirect" <?php selected( self::get_setting( 'after_add_action', 'browse' ), 'redirect' ); ?>>
                                            <?php esc_html_e( 'Redirect to the quote page', 'wpc-request-a-quote' ); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Choose what happens after a product is successfully added to the quote list.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_hide_price"><?php esc_html_e( 'Hide price', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <input type="checkbox" id="wpcrq_settings_hide_price"
                                           name="wpcrq_settings[hide_price]"
                                           value="yes" <?php checked( self::get_setting( 'hide_price', 'no' ), 'yes' ); ?> />
                                    <span class="description">
                                        <?php esc_html_e( 'If checked, the price will be hidden for all products that have the "Add to Quote" button enabled.', 'wpc-request-a-quote' ); ?>
                                    </span>
                                </td>
                            </tr>
                            <tr class="heading">
                                <th colspan="2">
                                    <?php esc_html_e( 'Page & Form', 'wpc-request-a-quote' ); ?>
                                </th>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_quote_page_id"><?php esc_html_e( 'Quote Page', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[quote_page_id]" id="wpcrq_settings_quote_page_id"
                                            class="wpc-select2"
                                            style="width: 300px;">
                                        <?php foreach ( $page_options as $id => $title ): ?>
                                            <option value="<?php echo esc_attr( $id ); ?>" <?php selected( self::get_setting( 'quote_page_id' ), $id ); ?>><?php echo esc_html( $title ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Choose the page where you want to display the quote list. Make sure the page contains the shortcode', 'wpc-request-a-quote' ); ?>
                                        <code>[wpcrq_quote_page]</code>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_form_layout"><?php esc_html_e( 'Request Form Layout', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[form_layout]" id="wpcrq_settings_form_layout"
                                            style="width: 300px;">
                                        <option value="below" <?php selected( self::get_setting( 'form_layout', 'below' ), 'below' ); ?>><?php esc_html_e( 'Below the product table', 'wpc-request-a-quote' ); ?></option>
                                        <option value="right" <?php selected( self::get_setting( 'form_layout', 'below' ), 'right' ); ?>><?php esc_html_e( 'On the right of product table', 'wpc-request-a-quote' ); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Choose where to display the request form. Default is Below.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_show_subtotal"><?php esc_html_e( 'Show Subtotal Column', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[show_subtotal]" id="wpcrq_settings_show_subtotal"
                                            style="width: 300px;">
                                        <option value="no" <?php selected( self::get_setting( 'show_subtotal', 'no' ), 'no' ); ?>>
                                            <?php esc_html_e( 'No', 'wpc-request-a-quote' ); ?></option>
                                        <option value="yes" <?php selected( self::get_setting( 'show_subtotal', 'no' ), 'yes' ); ?>>
                                            <?php esc_html_e( 'Yes', 'wpc-request-a-quote' ); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Display the Subtotal column in the quote list table. Default is No.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label><?php esc_html_e( 'Quantity Limit', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <div style="display: flex; gap: 20px; align-items: center;">
                                        <div style="display: flex; flex-direction: column; gap: 5px;">
                                            <label
                                                    for="wpcrq_settings_min_qty"
                                                    style="font-size: 12px; font-weight: 500; color: #666;"><?php esc_html_e( 'Min', 'wpc-request-a-quote' ); ?></label>
                                            <input type="number" id="wpcrq_settings_min_qty"
                                                   name="wpcrq_settings[min_qty]"
                                                   value="<?php echo esc_attr( self::get_setting( 'min_qty', '' ) ); ?>"
                                                   min="0"
                                                   step="1" style="width: 100px;"/>
                                        </div>
                                        <div style="display: flex; flex-direction: column; gap: 5px;">
                                            <label
                                                    for="wpcrq_settings_max_qty"
                                                    style="font-size: 12px; font-weight: 500; color: #666;"><?php esc_html_e( 'Max', 'wpc-request-a-quote' ); ?></label>
                                            <input type="number" id="wpcrq_settings_max_qty"
                                                   name="wpcrq_settings[max_qty]"
                                                   value="<?php echo esc_attr( self::get_setting( 'max_qty', '' ) ); ?>"
                                                   min="0"
                                                   step="1" style="width: 100px;"/>
                                        </div>
                                    </div>
                                    <p class="description">
                                        <?php esc_html_e( 'Set minimum and maximum total quantity allowed per quote. Leave 0 or empty to disable.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_max_message_length"><?php esc_html_e( 'Message Maximum Characters', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="wpcrq_settings_max_message_length"
                                           name="wpcrq_settings[max_message_length]"
                                           value="<?php echo esc_attr( self::get_setting( 'max_message_length', 255 ) ); ?>"
                                           min="0"
                                           step="1"/>
                                    <p class="description">
                                        <?php esc_html_e( 'Maximum number of characters allowed in the message field. Default is 255. Leave 0 or empty to disable.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr class="heading">
                                <th colspan="2">
                                    <?php esc_html_e( 'Emails', 'wpc-request-a-quote' ); ?>
                                </th>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_quote_request_price"><?php esc_html_e( 'Quote Request Email Price', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[quote_request_price]"
                                            id="wpcrq_settings_quote_request_price"
                                            style="width: 300px;">
                                        <option value="no" <?php selected( self::get_setting( 'quote_request_price', 'no' ), 'no' ); ?>>
                                            <?php esc_html_e( 'Hide', 'wpc-request-a-quote' ); ?></option>
                                        <option value="yes" <?php selected( self::get_setting( 'quote_request_price', 'no' ), 'yes' ); ?>><?php esc_html_e( 'Show', 'wpc-request-a-quote' ); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Display product prices and totals in the initial quote request email sent to the customer.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label
                                            for="wpcrq_settings_quote_updated_price"><?php esc_html_e( 'Quote Updated Email Price', 'wpc-request-a-quote' ); ?></label>
                                </th>
                                <td>
                                    <select name="wpcrq_settings[quote_updated_price]"
                                            id="wpcrq_settings_quote_updated_price"
                                            style="width: 300px;">
                                        <option value="no" <?php selected( self::get_setting( 'quote_updated_price', 'no' ), 'no' ); ?>>
                                            <?php esc_html_e( 'Hide All Pricing', 'wpc-request-a-quote' ); ?></option>
                                        <option value="price_column_only" <?php selected( self::get_setting( 'quote_updated_price', 'no' ), 'price_column_only' ); ?>>
                                            <?php esc_html_e( 'Hide Price Column Only', 'wpc-request-a-quote' ); ?></option>
                                        <option value="yes" <?php selected( self::get_setting( 'quote_updated_price', 'no' ), 'yes' ); ?>><?php esc_html_e( 'Show All Pricing', 'wpc-request-a-quote' ); ?></option>
                                    </select>
                                    <p class="description">
                                        <?php esc_html_e( 'Choose how pricing is displayed in the "Quote Updated" email sent to the customer.', 'wpc-request-a-quote' ); ?>
                                    </p>
                                </td>
                            </tr>
                            <tr class="submit">
                                <th colspan="2">
                                    <div class="wpclever_submit">
                                        <?php
                                        settings_fields( 'wpcrq_settings' );
                                        submit_button( '', 'primary', 'submit', false );

                                        if ( function_exists( 'wpc_last_saved' ) ) {
                                            wpc_last_saved( get_option( 'wpcrq_settings', [] ) );
                                        }
                                        ?>
                                    </div>
                                    <a style="display: none;" class="wpclever_export"
                                       data-key="wpcrq_settings"
                                       data-name="settings"
                                       href="#"><?php esc_html_e( 'import / export', 'wpc-request-a-quote' ); ?></a>
                                </th>
                            </tr>
                        </table>
                    </form>
                <?php } else if ( $active_tab === 'localization' ) {
                    $localization = get_option( 'wpcrq_localization', [] );
                    $strings      = WPCRQ_Localization::get_localized_strings();
                    ?>
                    <form method="post" action="options.php">
                        <table class="form-table">
                            <tr class="heading">
                                <th scope="row"><?php esc_html_e( 'Localization', 'wpc-request-a-quote' ); ?></th>
                                <td>
                                    <?php esc_html_e( 'Leave blank to use the default text and its equivalent translation in multiple languages.', 'wpc-request-a-quote' ); ?>
                                </td>
                            </tr>
                            <?php foreach ( $strings as $key => $data ) : ?>
                                <tr>
                                    <th scope="row">
                                        <label for="wpcrq_localization_<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $data['label'] ); ?></label>
                                    </th>
                                    <td>
                                        <input type="text"
                                               id="wpcrq_localization_<?php echo esc_attr( $key ); ?>"
                                               name="wpcrq_localization[<?php echo esc_attr( $key ); ?>]"
                                               value="<?php echo esc_attr( $localization[ $key ] ?? '' ); ?>"
                                               style="width: 400px;"
                                               placeholder="<?php echo esc_attr( $data['default'] ); ?>"/>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <tr class="submit">
                                <th colspan="2">
                                    <div class="wpclever_submit">
                                        <?php
                                        settings_fields( 'wpcrq_localization' );
                                        submit_button( '', 'primary', 'submit', false );

                                        if ( function_exists( 'wpc_last_saved' ) ) {
                                            wpc_last_saved( get_option( 'wpcrq_localization', [] ) );
                                        }
                                        ?>
                                    </div>
                                    <a style="display: none;" class="wpclever_export"
                                       data-key="wpcrq_localization"
                                       data-name="settings"
                                       href="#"><?php esc_html_e( 'import / export', 'wpc-request-a-quote' ); ?></a>
                                </th>
                            </tr>
                        </table>
                    </form>
                <?php } else if ( $active_tab === 'statistics' ) {
                    // phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filter params for statistics display.
                    $filter     = isset( $_GET['filter'] ) ? sanitize_text_field( wp_unslash( $_GET['filter'] ?? '' ) ) : '7';
                    $start_date = isset( $_GET['start_date'] ) ? sanitize_text_field( wp_unslash( $_GET['start_date'] ?? '' ) ) : '';
                    $end_date   = isset( $_GET['end_date'] ) ? sanitize_text_field( wp_unslash( $_GET['end_date'] ?? '' ) ) : '';
                    // phpcs:enable WordPress.Security.NonceVerification.Recommended

                    $days       = ( 'custom' === $filter ) ? 0 : absint( $filter );
                    $stats      = WPCRQ_Statistics::get_stats( $days, $start_date, $end_date );
                    $chart_data = WPCRQ_Statistics::get_chart_data( $days, $start_date, $end_date );
                    ?>
                    <div class="wpclever_settings_page_content_text">
                        <div class="wpcrq-stats-wrap">
                            <div class="wpcrq-stats-header"
                                 style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                <div class="wpcrq-stats-filter"
                                     style="background: #fff; padding: 10px 15px; border-radius: 4px; border: 1px solid #ccd0d4;">
                                    <form method="get" action="">
                                        <input type="hidden" name="page" value="wpclever-wpcrq">
                                        <input type="hidden" name="tab" value="statistics">
                                        <select name="filter" id="wpcrq-filter-select" onchange="this.form.submit()">
                                            <option value="7" <?php selected( $filter, '7' ); ?>>
                                                <?php esc_html_e( 'Last 7 days', 'wpc-request-a-quote' ); ?></option>
                                            <option value="30" <?php selected( $filter, '30' ); ?>>
                                                <?php esc_html_e( 'Last 30 days', 'wpc-request-a-quote' ); ?></option>
                                            <option value="custom" <?php selected( $filter, 'custom' ); ?>>
                                                <?php esc_html_e( 'Custom range', 'wpc-request-a-quote' ); ?></option>
                                        </select>

                                        <span class="custom-date-fields"
                                              style="<?php echo esc_attr( ( 'custom' === $filter ) ? '' : 'display:none;' ); ?> margin-left: 10px;">
							<input type="date" name="start_date" value="<?php echo esc_attr( $start_date ); ?>">
							<?php esc_html_e( 'to', 'wpc-request-a-quote' ); ?>
							<input type="date" name="end_date" value="<?php echo esc_attr( $end_date ); ?>">
							<button type="submit"
                                    class="button"><?php esc_html_e( 'Filter', 'wpc-request-a-quote' ); ?></button>
						</span>
                                    </form>
                                </div>
                            </div>
                            <div class="wpcrq-chart-container"
                                 style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); border: 1px solid #ccd0d4; margin-bottom: 30px;">
                                <canvas id="wpcrq-main-chart" style="max-height: 400px; width: 100%;"></canvas>
                            </div>
                            <div class="wpcrq-stats-grid"
                                 style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                                <div class="stat-card"
                                     style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border-left: 4px solid #3498db;">
                                    <h3 style="margin-top: 0; color: #666; font-size: 14px; text-transform: uppercase;">
                                        <?php esc_html_e( 'Quotes Received', 'wpc-request-a-quote' ); ?></h3>
                                    <div class="stat-value" style="font-size: 32px; font-weight: bold; color: #2c3e50;">
                                        <?php echo esc_html( $stats['received'] ); ?></div>
                                </div>
                                <div class="stat-card"
                                     style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border-left: 4px solid #f1c40f;">
                                    <h3 style="margin-top: 0; color: #666; font-size: 14px; text-transform: uppercase;">
                                        <?php esc_html_e( 'Quotes Reviewed', 'wpc-request-a-quote' ); ?></h3>
                                    <div class="stat-value" style="font-size: 32px; font-weight: bold; color: #2c3e50;">
                                        <?php echo esc_html( $stats['reviewed'] ); ?></div>
                                </div>
                                <div class="stat-card"
                                     style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border-left: 4px solid #2ecc71;">
                                    <h3 style="margin-top: 0; color: #666; font-size: 14px; text-transform: uppercase;">
                                        <?php esc_html_e( 'Quotes Accepted', 'wpc-request-a-quote' ); ?></h3>
                                    <div class="stat-value" style="font-size: 32px; font-weight: bold; color: #2c3e50;">
                                        <?php echo esc_html( $stats['accepted'] ); ?></div>
                                </div>
                                <div class="stat-card"
                                     style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border-left: 4px solid #e74c3c;">
                                    <h3 style="margin-top: 0; color: #666; font-size: 14px; text-transform: uppercase;">
                                        <?php esc_html_e( 'Quotes Rejected', 'wpc-request-a-quote' ); ?></h3>
                                    <div class="stat-value" style="font-size: 32px; font-weight: bold; color: #2c3e50;">
                                        <?php echo esc_html( $stats['rejected'] ); ?></div>
                                </div>
                                <div class="stat-card"
                                     style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center; border-left: 4px solid #9b59b6;">
                                    <h3 style="margin-top: 0; color: #666; font-size: 14px; text-transform: uppercase;">
                                        <?php esc_html_e( 'Quotes Paid', 'wpc-request-a-quote' ); ?></h3>
                                    <div class="stat-value" style="font-size: 32px; font-weight: bold; color: #2c3e50;">
                                        <?php echo esc_html( $stats['paid'] ); ?></div>
                                </div>
                            </div>
                            <h3 style="margin-top: 40px;"><?php esc_html_e( 'Conversion Rates', 'wpc-request-a-quote' ); ?></h3>
                            <div class="wpcrq-stats-grid"
                                 style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px;">
                                <?php
                                $total              = $stats['received'] ?: 1;
                                $conversion_metrics = [
                                        'review_rate'     => [
                                                'label' => __( 'Review Rate', 'wpc-request-a-quote' ),
                                                'val'   => $stats['reviewed'],
                                                'color' => '#f1c40f'
                                        ],
                                        'acceptance_rate' => [
                                                'label' => __( 'Acceptance Rate', 'wpc-request-a-quote' ),
                                                'val'   => $stats['accepted'],
                                                'color' => '#2ecc71'
                                        ],
                                        'payment_rate'    => [
                                                'label' => __( 'Payment Rate', 'wpc-request-a-quote' ),
                                                'val'   => $stats['paid'],
                                                'color' => '#9b59b6'
                                        ],
                                ];

                                foreach ( $conversion_metrics as $key => $metric ):
                                    $percentage = round( ( $metric['val'] / $total ) * 100, 1 );
                                    ?>
                                    <div class="stat-card"
                                         style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); text-align: center;">
                                        <h3 style="margin-top: 0; color: #666; font-size: 14px; text-transform: uppercase;">
                                            <?php echo esc_html( $metric['label'] ); ?></h3>
                                        <div class="stat-value"
                                             style="font-size: 28px; font-weight: bold; color: <?php echo esc_attr( $metric['color'] ); ?>;">
                                            <?php echo esc_html( $percentage ); ?>%
                                        </div>
                                        <div class="progress-bar-wrap"
                                             style="background: #eee; height: 8px; border-radius: 4px; margin-top: 15px; overflow: hidden;">
                                            <div class="progress-bar"
                                                 style="background: <?php echo esc_attr( $metric['color'] ); ?>; height: 100%; width: <?php echo esc_attr( $percentage ); ?>%;">
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <script>
                                document.getElementById('wpcrq-filter-select').addEventListener('change', function () {
                                    if (this.value === 'custom') {
                                        document.querySelector('.custom-date-fields').style.display = 'inline-block';
                                    } else {
                                        document.querySelector('.custom-date-fields').style.display = 'none';
                                    }
                                });

                                // Initialize Chart
                                document.addEventListener('DOMContentLoaded', function () {
                                    const ctx = document.getElementById('wpcrq-main-chart').getContext('2d');
                                    const chartData = <?php echo wp_json_encode( $chart_data ); ?>;

                                    new Chart(ctx, {
                                        type: 'line',
                                        data: {
                                            labels: chartData.labels,
                                            datasets: chartData.datasets
                                        },
                                        options: {
                                            responsive: true,
                                            maintainAspectRatio: false,
                                            interaction: {
                                                mode: 'index',
                                                intersect: false,
                                            },
                                            plugins: {
                                                legend: {
                                                    position: 'top',
                                                },
                                                tooltip: {
                                                    padding: 10,
                                                    backgroundColor: 'rgba(0,0,0,0.8)',
                                                }
                                            },
                                            scales: {
                                                y: {
                                                    beginAtZero: true,
                                                    ticks: {
                                                        stepSize: 1
                                                    }
                                                }
                                            }
                                        }
                                    });
                                });
                            </script>
                        </div>
                    </div>
                <?php } elseif ( $active_tab === 'premium' ) { ?>
                    <div class="wpclever_settings_page_content_text">
                        <p>
                            Get the Premium Version just $29!
                            <a href="https://wpclever.net/downloads/request-a-quote/?utm_source=pro&utm_medium=wpcrq&utm_campaign=wporg"
                               target="_blank">https://wpclever.net/downloads/request-a-quote/</a>
                        </p>
                        <p><strong>Extra features for Premium Version:</strong></p>
                        <ul style="margin-bottom: 0">
                            <li>- Get insights into your quote performance with a built-in dashboard.</li>
                            <li>- Enable "Request a Quote" as a payment method at checkout.</li>
                            <li>- Get the lifetime update & premium support.</li>
                        </ul>
                    </div>
                <?php } ?>
            </div><!-- /.wpclever_settings_page_content -->
            <div class="wpclever_settings_page_suggestion">
                <div class="wpclever_settings_page_suggestion_label">
                    <span class="dashicons dashicons-yes-alt"></span> Suggestion
                </div>
                <div class="wpclever_settings_page_suggestion_content">
                    <div>
                        To display custom engaging real-time messages on any wished positions, please
                        install
                        <a href="https://wordpress.org/plugins/wpc-smart-messages/" target="_blank">WPC
                            Smart Messages</a> plugin. It's free!
                    </div>
                    <div>
                        Wanna save your precious time working on variations? Try our brand-new free plugin
                        <a href="https://wordpress.org/plugins/wpc-variation-bulk-editor/" target="_blank">WPC
                            Variation Bulk Editor</a> and
                        <a href="https://wordpress.org/plugins/wpc-variation-duplicator/" target="_blank">WPC
                            Variation Duplicator</a>.
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public static function action_links( $links, $file ) {
        static $plugin;

        if ( ! isset( $plugin ) ) {
            $plugin = plugin_basename( WPCRQ_FILE );
        }

        if ( $plugin === $file ) {
            $settings = '<a href="' . esc_url( admin_url( 'admin.php?page=wpclever-wpcrq&tab=settings' ) ) . '">' . esc_html__( 'Settings', 'wpc-request-a-quote' ) . '</a>';
            //$links['wpc-premium'] = '<a href="' . esc_url( admin_url( 'admin.php?page=wpclever-wpcrq&tab=premium' ) ) . '">' . esc_html__( 'Premium Version', 'wpc-request-a-quote' ) . '</a>';
            array_unshift( $links, $settings );
        }

        return (array) $links;
    }

    public static function row_meta( $links, $file ) {
        static $plugin;

        if ( ! isset( $plugin ) ) {
            $plugin = plugin_basename( WPCRQ_FILE );
        }

        if ( $plugin === $file ) {
            $row_meta = [
                    'support' => '<a href="' . esc_url( WPCRQ_DISCUSSION ) . '" target="_blank">' . esc_html__( 'Community support', 'wpc-request-a-quote' ) . '</a>',
            ];

            return array_merge( $links, $row_meta );
        }

        return (array) $links;
    }
}

WPCRQ_Settings::init();
