<?php
/**
 * Product Meta for WPC Request a Quote
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Product_Meta {
	public static function init() {
		// Add the 'Request a Quote' tab
		add_filter( 'woocommerce_product_data_tabs', [ __CLASS__, 'add_product_data_tab' ] );
		// Add the panel content
		add_action( 'woocommerce_product_data_panels', [ __CLASS__, 'add_product_data_panel' ] );
		// Save the meta fields
		add_action( 'woocommerce_process_product_meta', [ __CLASS__, 'save_product_meta' ] );
	}

	public static function add_product_data_tab( $tabs ) {
		$tabs['wpcrq'] = [
			'label'  => __( 'Request a Quote', 'wpc-request-a-quote' ),
			'target' => 'wpcrq_product_data',
			'class'  => [ 'show_if_simple', 'show_if_variable', 'show_if_grouped', 'show_if_external' ],
		];

		return $tabs;
	}

	public static function add_product_data_panel() {
		global $post;

		echo '<div id="wpcrq_product_data" class="panel woocommerce_options_panel">';
		echo '<div class="options_group">';

		woocommerce_wp_select(
			[
				'id'          => '_wpcrq_allowed_quote',
				'label'       => __( 'Allowed Quote', 'wpc-request-a-quote' ),
				'description' => __( 'Choose whether this specific product can be requested for a quote. Selecting "Yes" or "No" overrides global settings.', 'wpc-request-a-quote' ),
				'desc_tip'    => true,
				'options'     => [
					'default' => __( 'Default (Follows global settings)', 'wpc-request-a-quote' ),
					'yes'     => __( 'Yes (Force allow)', 'wpc-request-a-quote' ),
					'no'      => __( 'No (Force disallow)', 'wpc-request-a-quote' ),
				],
			]
		);

		echo '</div>';
		echo '</div>';
	}

	public static function save_product_meta( $post_id ) {
		if ( ! isset( $_POST['woocommerce_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['woocommerce_meta_nonce'] ) ), 'woocommerce_save_data' ) ) {
			return;
		}

		if ( isset( $_POST['_wpcrq_allowed_quote'] ) ) {
			update_post_meta( $post_id, '_wpcrq_allowed_quote', sanitize_key( wp_unslash( $_POST['_wpcrq_allowed_quote'] ?? '' ) ) );
		}
	}
}

WPCRQ_Product_Meta::init();
