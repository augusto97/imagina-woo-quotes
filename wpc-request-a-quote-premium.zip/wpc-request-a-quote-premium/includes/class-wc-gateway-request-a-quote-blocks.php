<?php
/**
 * WC_Gateway_Request_A_Quote_Blocks_Support Class
 *
 * Integrates the "Request a Quote" payment gateway with WooCommerce Checkout Blocks.
 * This class extends AbstractPaymentMethodType to register the gateway's script
 * handles and pass necessary data to the client-side component.
 */
defined( 'ABSPATH' ) || exit;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

class WC_Gateway_Request_A_Quote_Blocks_Support extends AbstractPaymentMethodType {

	/**
	 * Payment method name/ID — must match the gateway ID and the JS registerPaymentMethod name.
	 *
	 * @var string
	 */
	protected $name = 'request_a_quote';

	/**
	 * Initialize the block support — load gateway settings from the DB.
	 */
	public function initialize() {
		$this->settings = get_option( 'woocommerce_request_a_quote_settings', [] );
	}

	/**
	 * Check if the gateway is active/enabled.
	 * This controls whether the method appears at all in the Checkout Block.
	 *
	 * @return bool
	 */
	public function is_active() {
		// Must be enabled in WC payment settings AND enabled as a plugin feature.
		$wc_enabled     = ! empty( $this->settings['enabled'] ) && 'yes' === $this->settings['enabled'];
		$plugin_enabled = 'yes' === WPCRQ_Settings::get_setting( 'enable_payment_gateway', 'no' );

		return $wc_enabled && $plugin_enabled;
	}

	/**
	 * Register and return the script handles for the Checkout Block frontend.
	 * The registered script must call wc.wcBlocksRegistry.registerPaymentMethod().
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {
		$script_path = WPCRQ_DIR . 'assets/js/checkout-blocks.js';
		$script_url  = WPCRQ_URI . 'assets/js/checkout-blocks.js';
		$version     = file_exists( $script_path ) ? filemtime( $script_path ) : WPCRQ_VERSION;

		wp_register_script(
			'wpcrq-checkout-blocks',
			$script_url,
			[
				'wc-blocks-registry',
				'wc-blocks-data-store',
				'wc-settings',
				'wp-element',
				'wp-html-entities',
			],
			$version,
			true
		);

		return [ 'wpcrq-checkout-blocks' ];
	}

	/**
	 * Return data passed to the client via getSetting( 'request_a_quote_data' ).
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		return [
			'title'       => $this->get_setting( 'title', __( 'Request a Quote', 'wpc-request-a-quote' ) ),
			'description' => $this->get_setting( 'description', '' ),
			'supports'    => [ 'products' ],
		];
	}
}
