<?php
/**
 * Frontend elements for WPC Request a Quote
 */
defined( 'ABSPATH' ) || exit;

class WPCRQ_Frontend {
	public static function init() {
		// Enqueue scripts and styles
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_scripts' ] );

		// Inject quote button into the WooCommerce Cart Block.
		// This hook fires only when the Cart Block is actually present on the page.
		add_action( 'woocommerce_blocks_enqueue_cart_block_scripts_after', [ __CLASS__, 'enqueue_cart_block_script' ] );

		// Button position on Single Product page
		$pos_single      = WPCRQ_Settings::get_setting( 'button_position_single', 'after' );
		$priority_single = ( 'before' === $pos_single ) ? 25 : 35;
		add_action( 'woocommerce_single_product_summary', [ __CLASS__, 'add_button_single' ], $priority_single );

		if ( 'replace' === $pos_single ) {
			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
		}

		// Button position on Loop (Shop/Archive)
		$pos_archive      = WPCRQ_Settings::get_setting( 'button_position_archive', 'after' );
		$priority_archive = ( 'before' === $pos_archive ) ? 5 : 15;
		add_action( 'woocommerce_after_shop_loop_item', [ __CLASS__, 'add_button_loop' ], $priority_archive );

		if ( 'replace' === $pos_archive ) {
			remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
		}

		// Handle Quote Review Page
		add_action( 'template_redirect', [ __CLASS__, 'handle_quote_review' ] );

		// Button on Cart page
		add_action( 'woocommerce_proceed_to_checkout', [ __CLASS__, 'add_quote_button_to_cart' ], 25 );
		add_action( 'template_redirect', [ __CLASS__, 'handle_cart_to_quote_action' ] );

		// Checkout button text
		add_filter( 'woocommerce_order_button_text', [ __CLASS__, 'order_button_text' ] );

		// Hide price if requested
		add_filter( 'woocommerce_get_price_html', [ __CLASS__, 'hide_price_if_quote' ], 99, 2 );
		add_filter( 'woocommerce_available_variation', [ __CLASS__, 'hide_variation_price_if_quote' ], 99, 3 );
	}

	public static function enqueue_scripts() {
		wp_enqueue_style( 'wpcrq-frontend', WPCRQ_URI . 'assets/css/frontend.css', [], WPCRQ_VERSION );
		wp_enqueue_script( 'wpcrq-frontend', WPCRQ_URI . 'assets/js/frontend.js', [ 'jquery' ], WPCRQ_VERSION, true );

		$quote_page_id    = WPCRQ_Settings::get_setting( 'quote_page_id' );
		$after_add_action = WPCRQ_Settings::get_setting( 'after_add_action', 'browse' );
		$quote_page_url   = $quote_page_id ? get_permalink( $quote_page_id ) : '';

		wp_localize_script( 'wpcrq-frontend', 'wpcrq_vars', [
			'ajaxurl'            => admin_url( 'admin-ajax.php' ),
			'nonce'              => wp_create_nonce( 'wpcrq-nonce' ),
			'wc_ajax'            => WC_AJAX::get_endpoint( '%%endpoint%%' ),
			'after_add_action'   => $after_add_action,
			'quote_page_url'     => $quote_page_url,
			'browse_quote_txt'   => WPCRQ_Localization::get_text( 'browse_quote' ),
			'add_to_quote_txt'   => WPCRQ_Localization::get_text( 'add_to_quote' ),
			'added_txt'          => WPCRQ_Localization::get_text( 'added_to_quote' ),
			'submit_request_txt' => WPCRQ_Localization::get_text( 'submit_request' ),
			'place_order_txt'    => self::get_default_checkout_button_text(),
			'message_too_long'   => WPCRQ_Localization::get_text( 'message_too_long' ),
			'generic_error'      => WPCRQ_Localization::get_text( 'generic_error' ),
			'update_error'       => WPCRQ_Localization::get_text( 'update_error' ),
		] );
	}

	/**
	 * Enqueue the Cart Block integration script.
	 * Called via woocommerce_blocks_enqueue_cart_block_scripts_after which only
	 * fires when the WooCommerce Cart Block is actually rendering on the current page.
	 * This guarantees all WC Blocks globals (wc.blocksCheckout, etc.) are available.
	 */
	public static function enqueue_cart_block_script() {
		$enable_gateway = WPCRQ_Settings::get_setting( 'enable_payment_gateway', 'no' );
		if ( 'yes' !== $enable_gateway ) {
			return;
		}

		if ( ! self::can_request_quote() ) {
			return;
		}

		// Build the cart-to-quote redirect URL with a nonce for CSRF protection.
		$quote_url = add_query_arg(
			[
				'wpcrq-action' => 'add-cart-to-quote',
				'nonce'        => wp_create_nonce( 'wpcrq-cart-to-quote' ),
			],
			wc_get_cart_url()
		);

		wp_enqueue_script(
			'wpcrq-cart-block',
			WPCRQ_URI . 'assets/js/cart-block.js',
			[ 'wc-blocks-data-store' ],
			WPCRQ_VERSION,
			true
		);

		wp_localize_script( 'wpcrq-cart-block', 'wpcrqCartBlock', [
			'quoteUrl'   => $quote_url,
			'buttonText' => WPCRQ_Localization::get_text( 'request_quote_this_cart' ),
		] );
	}

	private static function get_default_checkout_button_text() {
		remove_filter( 'woocommerce_order_button_text', [ __CLASS__, 'order_button_text' ] );
		$text = apply_filters( 'woocommerce_order_button_text', __( 'Place order', 'wpc-request-a-quote' ) );
		add_filter( 'woocommerce_order_button_text', [ __CLASS__, 'order_button_text' ] );

		return $text;
	}

	public static function can_request_quote( $product_id = 0 ) {
		// Check per-product override first
		if ( $product_id ) {
			$allowed_quote = get_post_meta( $product_id, '_wpcrq_allowed_quote', true );
			if ( 'yes' === $allowed_quote ) {
				return true;
			} elseif ( 'no' === $allowed_quote ) {
				return false;
			}
		}

		$allowed_roles = WPCRQ_Settings::get_setting( 'allowed_roles', [ 'all' ] );
		if ( empty( $allowed_roles ) || ! is_array( $allowed_roles ) ) {
			$allowed_roles = [ 'all' ];
		}

		$role_allowed = false;
		if ( in_array( 'all', $allowed_roles, true ) ) {
			$role_allowed = true;
		} elseif ( is_user_logged_in() ) {
			$user       = wp_get_current_user();
			$user_roles = (array) $user->roles;

			if ( in_array( 'logged_in', $allowed_roles, true ) ) {
				$role_allowed = true;
			} else {
				foreach ( $user_roles as $role ) {
					if ( in_array( $role, $allowed_roles, true ) ) {
						$role_allowed = true;
						break;
					}
				}
			}
		} else {
			if ( in_array( 'guest', $allowed_roles, true ) ) {
				$role_allowed = true;
			}
		}

		if ( ! $role_allowed ) {
			return false;
		}

		// Check categories and types if product ID is provided
		if ( $product_id ) {
			$product = wc_get_product( $product_id );

			if ( $product ) {
				// Check allowed types
				$allowed_types = WPCRQ_Settings::get_setting( 'allowed_types', [ 'all' ] );
				if ( empty( $allowed_types ) || ! is_array( $allowed_types ) ) {
					$allowed_types = [ 'all' ];
				}

				if ( ! in_array( 'all', $allowed_types, true ) ) {
					$product_type = $product->get_type();
					if ( ! in_array( $product_type, $allowed_types, true ) ) {
						return false; // Product type not allowed
					}
				}
			}

			// Check allowed categories
			$allowed_categories = WPCRQ_Settings::get_setting( 'allowed_categories', [] );
			if ( ! is_array( $allowed_categories ) ) {
				$allowed_categories = [ $allowed_categories ];
			}

			// If no categories are selected, it means all categories are allowed
			if ( ! empty( $allowed_categories ) ) {
				$product_cats = wp_get_post_terms( $product_id, 'product_cat', [ 'fields' => 'ids' ] );
				if ( ! is_wp_error( $product_cats ) ) {
					$intersect = array_intersect( $allowed_categories, $product_cats );
					if ( empty( $intersect ) ) {
						return false; // Product does not belong to any allowed category
					}
				}
			}
		}

		return true;
	}

	public static function add_button_single() {
		echo wp_kses_post( self::get_button_html( 0, 'single' ) );
	}

	public static function add_button_loop() {
		echo wp_kses_post( self::get_button_html( 0, 'archive' ) );
	}

	public static function get_button_html( $product_id = 0, $context = 'single' ) {
		if ( ! $product_id ) {
			global $product;
			if ( $product ) {
				$product_id = $product->get_id();
			}
		}

		if ( ! $product_id ) {
			return '';
		}

		if ( ! self::can_request_quote( $product_id ) ) {
			return '';
		}

		$wpcrq_product = wc_get_product( $product_id );
		$is_variable   = $wpcrq_product->is_type( 'variable' );
		$is_added    = WPCRQ_Session::is_in_quote( $product_id );
		$btn_text    = $is_added ? WPCRQ_Localization::get_text( 'added_to_quote' ) : WPCRQ_Localization::get_text( 'add_to_quote' );
		$output      = '';

		if ( 'archive' === $context ) {
			$output .= '<div class="wpcrq-add-to-quote-wrapper wpcrq-loop" data-product_id="' . esc_attr( $product_id ) . '">';
			if ( $is_variable ) {
				$output .= '<a href="' . esc_url( get_permalink( $product_id ) ) . '" class="button wpcrq-btn wpcrq-select-options' . ( $is_added ? ' added' : '' ) . '">';
				$output .= esc_html( $btn_text );
				$output .= '</a>';
			} else {
				$output .= '<a href="#" class="button wpcrq-btn wpcrq-add-to-quote' . ( $is_added ? ' added' : '' ) . '" data-product_id="' . esc_attr( $product_id ) . '" data-quantity="1">';
				$output .= esc_html( $btn_text );
				$output .= '</a>';
			}
			$output .= '</div>';
		} else {
			$classes = 'wpcrq-add-to-quote-wrapper wpcrq-single';

			if ( $is_variable ) {
				$classes .= ' wpcrq-is-variable wpcrq-variation-selection-needed';
			}

			$output .= '<div class="' . esc_attr( $classes ) . '" data-product_id="' . esc_attr( $product_id ) . '">';
			$output .= '<a href="#" class="button wpcrq-btn wpcrq-add-to-quote' . ( $is_added ? ' added' : '' ) . '" data-product_id="' . esc_attr( $product_id ) . '" data-is_variable="' . ( $is_variable ? 1 : 0 ) . '" data-quantity="1">';
			$output .= esc_html( $btn_text );
			$output .= '</a>';
			$output .= '</div>';
		}

		return $output;
	}

	public static function handle_quote_review() {
		if ( ! isset( $_GET['wpcrq-quote'] ) || ! isset( $_GET['key'] ) ) {
			return;
		}

		$order_id  = absint( wp_unslash( $_GET['wpcrq-quote'] ?? '' ) );
		$order_key = sanitize_text_field( wp_unslash( $_GET['key'] ?? '' ) );
		$order     = wc_get_order( $order_id );

		if ( ! $order || $order->get_order_key() !== $order_key ) {
			include WPCRQ_DIR . 'templates/quote-error.php';
			exit;
		}

		$wpcrq_step = 'view';

		// Handle Actions
		if ( isset( $_POST['wpcrq_action'] ) && isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'wpcrq_quote_action' ) ) {
			$action = sanitize_text_field( wp_unslash( $_POST['wpcrq_action'] ?? '' ) );

			if ( 'accept' === $action ) {
				$wpcrq_step = 'shipping';
			} elseif ( 'confirm_accept' === $action ) {
				// Save Shipping Address
				$shipping_fields = [
					'first_name',
					'last_name',
					'company',
					'address_1',
					'address_2',
					'city',
					'state',
					'postcode',
					'country',
				];

				$shipping_data = [];
				foreach ( $shipping_fields as $field ) {
					if ( isset( $_POST[ 'shipping_' . $field ] ) ) {
						$shipping_data[ $field ] = sanitize_text_field( wp_unslash( $_POST[ 'shipping_' . $field ] ) );
					}
				}

				if ( ! empty( $shipping_data ) ) {
					$order->set_address( $shipping_data, 'shipping' );
				}

				// Copy billing to shipping if needed (optional, but good if form allows it)
				// For now, we trust the form data.

				$order->save();

				$order->update_status( 'pending', __( 'Quote accepted by customer with shipping info.', 'wpc-request-a-quote' ) );

				// Log for statistics
				WPCRQ_Statistics::log_event( $order_id, 'accepted' );

				wp_safe_redirect( $order->get_checkout_payment_url() );
				exit;
			} elseif ( 'reject' === $action ) {
				$order->update_status( 'quote-rejected', __( 'Quote rejected by customer.', 'wpc-request-a-quote' ) );
				wc_add_notice( __( 'The quote has been rejected.', 'wpc-request-a-quote' ) );

				// Log for statistics
				WPCRQ_Statistics::log_event( $order_id, 'rejected' );
			}
		}

		// Show Quote View Template
		include WPCRQ_DIR . 'templates/quote-view.php';
		exit;
	}

	public static function add_quote_button_to_cart() {
		$gateways = WC()->payment_gateways->get_available_payment_gateways();

		if ( ! isset( $gateways['request_a_quote'] ) || ! self::can_request_quote() ) {
			return;
		}

		$url = add_query_arg( [
			'wpcrq-action' => 'add-cart-to-quote',
			'nonce'        => wp_create_nonce( 'wpcrq-cart-to-quote' )
		], wc_get_cart_url() );

		echo '<a href="' . esc_url( $url ) . '" class="button wpcrq-cart-btn checkout-button">' . esc_html( WPCRQ_Localization::get_text( 'request_quote_this_cart' ) ) . '</a>';
	}

	public static function handle_cart_to_quote_action() {
		if ( ! isset( $_GET['wpcrq-action'] ) || 'add-cart-to-quote' !== sanitize_text_field( wp_unslash( $_GET['wpcrq-action'] ?? '' ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		if ( ! isset( $_GET['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['nonce'] ) ), 'wpcrq-cart-to-quote' ) ) {
			return;
		}

		if ( ! WC()->cart->is_empty() ) {
			// Set Request a Quote as the chosen payment method
			WC()->session->set( 'chosen_payment_method', 'request_a_quote' );

			// Redirect to checkout
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
	}

	public static function order_button_text( $button_text ) {
		if ( WC()->session->get( 'chosen_payment_method' ) === 'request_a_quote' ) {
			return WPCRQ_Localization::get_text( 'submit_request' );
		}

		return $button_text;
	}

	public static function hide_price_if_quote( $price, $product ) {
		if ( 'yes' !== WPCRQ_Settings::get_setting( 'hide_price', 'no' ) ) {
			return $price;
		}

		// Don't hide price in the cart or checkout where it matters
		if ( is_cart() || is_checkout() ) {
			return $price;
		}

		if ( self::can_request_quote( $product->get_id() ) ) {
			return '';
		}

		return $price;
	}

	public static function hide_variation_price_if_quote( $data, $product, $variation ) {
		if ( 'yes' !== WPCRQ_Settings::get_setting( 'hide_price', 'no' ) ) {
			return $data;
		}

		// Don't hide price in the cart or checkout where it matters
		if ( is_cart() || is_checkout() ) {
			return $data;
		}

		if ( self::can_request_quote( $product->get_id() ) ) {
			$data['price_html'] = '';
		}

		return $data;
	}
}

WPCRQ_Frontend::init();
