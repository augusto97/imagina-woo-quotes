/**
 * WooCommerce Checkout Blocks integration for "Request a Quote" payment method.
 *
 * Registers a client-side payment method so it appears inside the WooCommerce
 * Checkout Block. The server-side WC_Gateway_Request_A_Quote_Blocks_Support class
 * must be registered first to provide settings data via getSetting().
 */
( function () {
	'use strict';

	var registerPaymentMethod = window.wc.wcBlocksRegistry.registerPaymentMethod;
	var getSetting            = window.wc.wcSettings.getSetting;
	var createElement         = window.wp.element.createElement;
	var decodeEntities        = window.wp.htmlEntities.decodeEntities;

	// Retrieve settings passed from PHP get_payment_method_data().
	var settings    = getSetting( 'request_a_quote_data', {} );
	var title       = decodeEntities( settings.title || 'Request a Quote' );
	var description = decodeEntities( settings.description || '' );

	/**
	 * Content component — renders description below the selected radio button.
	 */
	var Content = function () {
		if ( ! description ) {
			return null;
		}

		return createElement( 'p', { className: 'wpcrq-blocks-description' }, description );
	};

	registerPaymentMethod( {
		// Must match the gateway $id and the PHP $name property exactly.
		name: 'request_a_quote',

		// label must be a React element or a plain string — NOT a function component.
		label: createElement( 'span', null, title ),

		// Content shown when this payment method is selected.
		content: createElement( Content, null ),

		// Content shown in the block editor preview.
		edit: createElement( Content, null ),

		// Determines whether this payment method is available in the current context.
		canMakePayment: function () {
			return true;
		},

		// Accessibility label for screen readers.
		ariaLabel: title,

		// Feature flags — must match the gateway's $supports array on the PHP side.
		supports: {
			features: settings.supports || [ 'products' ],
		},
	} );
}() );
