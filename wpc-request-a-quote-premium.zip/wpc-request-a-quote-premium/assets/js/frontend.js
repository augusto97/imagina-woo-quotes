(function ($) {
    'use strict';

    $(document).ready(function () {
        // Update Fragments
        var update_fragments = function (fragments) {
            if (fragments) {
                $.each(fragments, function (selector, value) {
                    $(selector).replaceWith(value);
                });
                $(document.body).trigger('wpcrq_fragments_refreshed');
            }
        };

        var update_buttons = function (item_ids) {
            item_ids = item_ids || [];

            $('.wpcrq-add-to-quote').each(function () {
                var $btn = $(this);
                var product_id = parseInt($btn.data('product_id'));

                if (item_ids.indexOf(product_id) !== -1) {
                    $btn.addClass('added');
                    if (wpcrq_vars.added_txt) {
                        $btn.text(wpcrq_vars.added_txt);
                    }
                } else {
                    $btn.removeClass('added');
                    if (wpcrq_vars.add_to_quote_txt) {
                        $btn.text(wpcrq_vars.add_to_quote_txt);
                    }
                }
            });
        };

        // Initial refresh on page load
        var cart_hash_key = 'wpcrq_cart_hash';
        var fragment_key = 'wpcrq_fragments';

        try {
            var cart_hash = sessionStorage.getItem(cart_hash_key);
            var fragments = JSON.parse(sessionStorage.getItem(fragment_key));

            if (cart_hash && fragments) {
                update_fragments(fragments);
            } else {
                $.ajax({
                    url: wpcrq_vars.ajaxurl, type: 'POST', data: {
                        action: 'wpcrq_get_refreshed_fragments'
                    }, success: function (response) {
                        if (response.success && response.data.fragments) {
                            sessionStorage.setItem(cart_hash_key, response.data.cart_hash);
                            sessionStorage.setItem(fragment_key, JSON.stringify(response.data.fragments));
                            update_fragments(response.data.fragments);
                        }
                    }
                });
            }
        } catch (err) {
            // Session storage not available or error
        }

        // Handle variations on single product page
        $(document).on('found_variation', 'form.variations_form', function (e, variation) {
            var product_id = $(this).data('product_id');
            var $btnWrapper = $('.wpcrq-add-to-quote-wrapper[data-product_id="' + product_id + '"]');
            var $btn = $btnWrapper.find('.wpcrq-add-to-quote');

            if (variation && variation.variation_id) {
                $btnWrapper.removeClass('wpcrq-variation-selection-needed');
                $btn.data('variation_id', variation.variation_id);
            } else {
                $btnWrapper.addClass('wpcrq-variation-selection-needed');
                $btn.data('variation_id', 0);
            }
        });

        $(document).on('reset_data', 'form.variations_form', function () {
            var product_id = $(this).data('product_id');
            var $btnWrapper = $('.wpcrq-add-to-quote-wrapper[data-product_id="' + product_id + '"]');
            var $btn = $btnWrapper.find('.wpcrq-add-to-quote');

            $btnWrapper.addClass('wpcrq-variation-selection-needed');
            $btn.data('variation_id', 0);
        });

        // Add to Quote Click Handler
        $(document).on('click', '.wpcrq-add-to-quote', function (e) {
            e.preventDefault();

            var $btn = $(this);

            if ($btn.closest('.wpcrq-variation-selection-needed').length > 0) {
                return;
            }

            var product_id = $btn.data('product_id');
            var quantity = 1;
            var variation_id = $btn.data('variation_id') || 0;
            var variation = {};

            // If on single product page, try to get current data
            if ($('.cart .quantity input.qty').length > 0) {
                quantity = $('.cart .quantity input.qty').val() || 1;
            }

            if (variation_id > 0) {
                $('form.variations_form select').each(function () {
                    variation[$(this).attr('name')] = $(this).val();
                });
            }

            $btn.addClass('loading');

            $.ajax({
                url: wpcrq_vars.ajaxurl, type: 'POST', data: {
                    action: 'wpcrq_add_to_quote',
                    nonce: wpcrq_vars.nonce,
                    product_id: product_id,
                    quantity: quantity,
                    variation_id: variation_id,
                    variation: variation
                }, success: function (response) {
                    $btn.removeClass('loading');

                    if (response.success) {
                        if (response.data.fragments) {
                            sessionStorage.setItem(cart_hash_key, response.data.cart_hash);
                            sessionStorage.setItem(fragment_key, JSON.stringify(response.data.fragments));
                            sessionStorage.setItem('wpcrq_item_ids', JSON.stringify(response.data.item_ids));
                            update_fragments(response.data.fragments);
                        }

                        if (response.data.item_ids) {
                            update_buttons(response.data.item_ids);
                        }

                        if (wpcrq_vars.after_add_action === 'redirect' && wpcrq_vars.quote_page_url) {
                            window.location.href = wpcrq_vars.quote_page_url;
                        } else if (wpcrq_vars.after_add_action === 'browse' && wpcrq_vars.quote_page_url) {
                            if ($btn.next('.wpcrq-browse-quote').length === 0) {
                                $btn.after(' <a href="' + wpcrq_vars.quote_page_url + '" class="wpcrq-browse-quote">' + wpcrq_vars.browse_quote_txt + '</a>');
                            }
                        }
                    } else {
                        alert(response.data && response.data.message ? response.data.message : (wpcrq_vars.generic_error || 'Error adding to quote.'));
                    }
                }
            });
        });

        // Remove from Quote
        $(document).on('click', '.wpcrq-remove-item', function (e) {
            e.preventDefault();

            var $btn = $(this);
            var item_key = $btn.data('item_key');
            var $row = $btn.closest('tr');

            $row.css('opacity', '0.5');

            $.ajax({
                url: wpcrq_vars.ajaxurl, type: 'POST', data: {
                    action: 'wpcrq_remove_from_quote', nonce: wpcrq_vars.nonce, item_key: item_key
                }, success: function (response) {
                    if (response.success) {
                        sessionStorage.setItem(cart_hash_key, response.data.cart_hash);
                        sessionStorage.setItem(fragment_key, JSON.stringify(response.data.fragments));
                        sessionStorage.setItem('wpcrq_item_ids', JSON.stringify(response.data.item_ids));
                        update_fragments(response.data.fragments);
                        update_buttons(response.data.item_ids);
                    } else {
                        $row.css('opacity', '1');
                    }
                }
            });
        });

        // Submit Quote Form
        $(document).on('submit', '#wpcrq-quote-form', function (e) {
            e.preventDefault();

            var $form = $(this);
            var $btn = $form.find('button[type="submit"]');
            var $response = $form.find('.wpcrq-form-response');

            var message = $('#wpcrq_message').val();
            var maxLength = $('#wpcrq_message').attr('maxlength');

            if (maxLength && message.length > parseInt(maxLength)) {
                alert(wpcrq_vars.message_too_long ? wpcrq_vars.message_too_long.replace('%s', maxLength) : 'Message is too long. The maximum allowed length is ' + maxLength + ' characters.');
                return;
            }

            $btn.prop('disabled', true).addClass('loading');
            $response.html('').removeClass('error success');

            var data = {
                action: 'wpcrq_submit_quote',
                nonce: wpcrq_vars.nonce,
                first_name: $('#wpcrq_first_name').val(),
                last_name: $('#wpcrq_last_name').val(),
                email: $('#wpcrq_email').val(),
                phone: $('#wpcrq_phone').val(),
                message: message,
            };

            $.ajax({
                url: wpcrq_vars.ajaxurl, type: 'POST', data: data, success: function (response) {
                    $btn.prop('disabled', false).removeClass('loading');
                    if (response.success) {
                        $response.addClass('success').html(response.data.message);
                        $('.wpcrq-quote-table-wrapper').slideUp();
                        $form.find('.form-row').slideUp();

                        sessionStorage.removeItem(cart_hash_key);
                        sessionStorage.removeItem(fragment_key);
                        sessionStorage.removeItem('wpcrq_item_ids');

                        update_buttons([]);

                        $(document).trigger('wpcrq_quote_requested_success', [$form, response]);
                    } else {
                        $response.addClass('error').html(response.data.message);
                        $(document).trigger('wpcrq_quote_requested_failed', [$form, response]);
                    }
                }, error: function () {
                    $btn.prop('disabled', false).removeClass('loading');
                    $response.addClass('error').html(wpcrq_vars.generic_error || 'An error occurred. Please try again.');
                }
            });
        });

        // Enable Update List button only on change
        var $updateBtn = $('.wpcrq-update-quote-btn');
        $updateBtn.prop('disabled', true);
        $(document).on('change input', '.wpcrq-quote-cart-form input.qty', function () {
            $updateBtn.prop('disabled', false);
        });

        // Update Quote List
        $(document).on('submit', '.wpcrq-quote-cart-form', function (e) {
            e.preventDefault();

            var $form = $(this);
            var $table = $form.find('.wpcrq-quote-table');
            var data = $form.serialize() + '&action=wpcrq_update_quote&nonce=' + wpcrq_vars.nonce;

            $table.addClass('processing').block({
                message: null, overlayCSS: {
                    background: '#fff', opacity: 0.6
                }
            });

            $.ajax({
                url: wpcrq_vars.ajaxurl, type: 'POST', data: data, success: function (response) {
                    if (response.success) {
                        if (response.data.fragments) {
                            sessionStorage.setItem(cart_hash_key, response.data.cart_hash);
                            sessionStorage.setItem(fragment_key, JSON.stringify(response.data.fragments));
                            sessionStorage.setItem('wpcrq_item_ids', JSON.stringify(response.data.item_ids));
                            update_fragments(response.data.fragments);
                            update_buttons(response.data.item_ids);
                        }
                    } else {
                        $table.removeClass('processing').unblock();
                        alert(response.data ? response.data.message : (wpcrq_vars.update_error || 'Error updating quote.'));
                    }
                }, error: function () {
                    $table.removeClass('processing').unblock();
                }
            });
        });


        // Checkout button text
        $(document.body).on('updated_checkout', function () {
            var $btn = $('#place_order');
            var payment_method = $('input[name="payment_method"]:checked').val();

            if (payment_method === 'request_a_quote') {
                $btn.html(wpcrq_vars.submit_request_txt);
            } else {
                $btn.html(wpcrq_vars.place_order_txt);
            }
        });

        $(document.body).on('change', 'input[name="payment_method"]', function () {
            $(document.body).trigger('updated_checkout');
        });

    });
})(jQuery);
