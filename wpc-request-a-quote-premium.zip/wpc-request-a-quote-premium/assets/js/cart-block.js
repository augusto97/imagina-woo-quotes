/**
 * WooCommerce Cart Block integration for "Request a Quote" button.
 *
 * Uses a MutationObserver to wait for the Cart Block to finish rendering,
 * then injects the "Request Quote this Cart" button after the
 * "Proceed to Checkout" block. Version-agnostic — does not rely on
 * the experimental Slot Fill API.
 */
( function () {
	'use strict';

	if ( ! window.wpcrqCartBlock ) {
		return;
	}

	var vars = window.wpcrqCartBlock;

	/**
	 * Create and insert the quote button into the Cart Block DOM.
	 * Inserts AFTER the "Proceed to Checkout" block.
	 *
	 * @returns {boolean} True if inserted or already present, false if target not found yet.
	 */
	function insertButton() {
		// Prevent duplicate insertion on React re-renders.
		if ( document.querySelector( '.wpcrq-cart-block-btn-wrap' ) ) {
			return true;
		}

		var checkoutBlock = document.querySelector( '.wp-block-woocommerce-proceed-to-checkout-block' );

		if ( ! checkoutBlock || ! checkoutBlock.parentNode ) {
			return false;
		}

		var wrapper = document.createElement( 'div' );
		wrapper.className = 'wpcrq-cart-block-btn-wrap';

		var link = document.createElement( 'a' );
		link.href        = vars.quoteUrl;
		link.className   = 'button wpcrq-cart-btn checkout-button';
		link.textContent = vars.buttonText;

		wrapper.appendChild( link );

		// Insert immediately AFTER the checkout block.
		var nextSibling = checkoutBlock.nextSibling;
		if ( nextSibling ) {
			checkoutBlock.parentNode.insertBefore( wrapper, nextSibling );
		} else {
			checkoutBlock.parentNode.appendChild( wrapper );
		}

		return true;
	}

	// Try immediately — Cart Block may already be rendered (e.g. cached page).
	if ( insertButton() ) {
		return;
	}

	// Watch for DOM changes until the Cart Block renders its checkout button.
	var observer = new MutationObserver( function () {
		if ( insertButton() ) {
			observer.disconnect();
		}
	} );

	observer.observe( document.body, {
		childList: true,
		subtree: true,
	} );

	// Safety cleanup: disconnect after 15 seconds to avoid memory leaks.
	setTimeout( function () {
		observer.disconnect();
	}, 15000 );
}() );
