<?php
/**
 * Quote Page Template
 */
defined( 'ABSPATH' ) || exit;

$wpcrq_items         = WPCRQ_Session::get_quote_items();
$wpcrq_show_subtotal = WPCRQ_Settings::get_setting( 'show_subtotal', 'no' );
$wpcrq_form_layout   = WPCRQ_Settings::get_setting( 'form_layout', 'below' );
?>
<div class="wpcrq-quote-page wpcrq-layout-<?php echo esc_attr( $wpcrq_form_layout ); ?>">
    <div class="wpcrq-quote-table-wrapper">
        <form class="wpcrq-quote-cart-form" action="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"
              method="post">
            <table class="wpcrq-quote-table shop_table cart">
                <thead>
                <tr>
                    <th class="product-remove">&nbsp;</th>
                    <th class="product-thumbnail">&nbsp;</th>
                    <th class="product-name"><?php echo esc_html( WPCRQ_Localization::get_text( 'product' ) ); ?></th>
                    <th class="product-quantity"><?php echo esc_html( WPCRQ_Localization::get_text( 'quantity' ) ); ?></th>
                    <?php if ( 'yes' === $wpcrq_show_subtotal ) : ?>
                        <th class="product-subtotal"><?php echo esc_html( WPCRQ_Localization::get_text( 'subtotal' ) ); ?></th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach ( $wpcrq_items as $wpcrq_item_key => $wpcrq_item ) {
                    $wpcrq_product = wc_get_product( $wpcrq_item['variation_id'] ?: $wpcrq_item['product_id'] );

                    if ( ! $wpcrq_product || ! $wpcrq_product->exists() ) {
                        continue;
                    }

                    // Set 'data' for WooCommerce functions that expect a cart item structure
                    $wpcrq_item['data'] = $wpcrq_product;

                    $wpcrq_product_permalink = apply_filters( 'woocommerce_product_permalink', $wpcrq_product->is_visible() ? $wpcrq_product->get_permalink( $wpcrq_item ) : '', $wpcrq_item, $wpcrq_item_key );
                    ?>
                    <tr class="wpcrq-quote-item" data-item_key="<?php echo esc_attr( $wpcrq_item_key ); ?>">
                        <td class="product-remove">
                            <?php
                            echo wp_kses_post( apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                    'wpcrq_quote_item_remove_link',
                                    sprintf(
                                            '<a href="#" class="remove wpcrq-remove-item" aria-label="%s" data-item_key="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                                            esc_html( WPCRQ_Localization::get_text( 'remove_item' ) ),
                                            esc_attr( $wpcrq_item_key ),
                                            esc_attr( $wpcrq_item['product_id'] ),
                                            esc_attr( $wpcrq_product->get_sku() )
                                    ),
                                    $wpcrq_item_key
                            ) );
                            ?>
                        </td>

                        <td class="product-thumbnail">
                            <?php
                            $wpcrq_thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $wpcrq_product->get_image(), $wpcrq_item, $wpcrq_item_key );

                            if ( ! $wpcrq_product_permalink ) {
                                echo wp_kses_post( $wpcrq_thumbnail );
                            } else {
                                printf( '<a href="%s">%s</a>', esc_url( $wpcrq_product_permalink ), wp_kses_post( $wpcrq_thumbnail ) );
                            }
                            ?>
                        </td>

                        <td class="product-name"
                            data-title="<?php echo esc_attr( WPCRQ_Localization::get_text( 'product' ) ); ?>">
                            <?php
                            if ( ! $wpcrq_product_permalink ) {
                                echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $wpcrq_product->get_name(), $wpcrq_item, $wpcrq_item_key ) . '&nbsp;' );
                            } else {
                                echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $wpcrq_product_permalink ), $wpcrq_product->get_name() ), $wpcrq_item, $wpcrq_item_key ) );
                            }

                            do_action( 'woocommerce_after_cart_item_name', $wpcrq_item, $wpcrq_item_key );

                            // Meta data.
                            echo wp_kses_post( wc_get_formatted_cart_item_data( $wpcrq_item ) );
                            ?>
                        </td>

                        <td class="product-quantity"
                            data-title="<?php echo esc_attr( WPCRQ_Localization::get_text( 'quantity' ) ); ?>">
                            <?php
                            if ( $wpcrq_product->is_sold_individually() ) {
                                $wpcrq_product_quantity = sprintf( '1 <input type="hidden" name="wpcrq_qty[%s]" value="1" />', $wpcrq_item_key );
                            } else {
                                $wpcrq_product_quantity = woocommerce_quantity_input(
                                        [
                                                'input_name'   => "wpcrq_qty[{$wpcrq_item_key}]",
                                                'input_value'  => $wpcrq_item['quantity'],
                                                'max_value'    => $wpcrq_product->get_max_purchase_quantity(),
                                                'min_value'    => '0',
                                                'product_name' => $wpcrq_product->get_name(),
                                        ],
                                        $wpcrq_product,
                                        false
                                );
                            }

                            echo wp_kses_post( apply_filters( 'wpcrq_quote_item_quantity', $wpcrq_product_quantity, $wpcrq_item_key, $wpcrq_item ) );
                            ?>
                        </td>

                        <?php if ( 'yes' === $wpcrq_show_subtotal ) : ?>
                            <td class="product-subtotal"
                                data-title="<?php echo esc_attr( WPCRQ_Localization::get_text( 'subtotal' ) ); ?>">
                                <?php
                                echo wp_kses_post( apply_filters( 'wpcrq_quote_item_subtotal', wc_price( (float) $wpcrq_product->get_price() * (int) $wpcrq_item['quantity'] ), $wpcrq_item, $wpcrq_item_key ) );
                                ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php
                }
                ?>
                <tr>
                    <td colspan="<?php echo esc_attr( ( 'yes' === $wpcrq_show_subtotal ) ? '5' : '4' ); ?>"
                        class="actions">
                        <button type="submit" class="button btn wpcrq-update-quote-btn" name="update_quote"
                                value="<?php echo esc_attr( WPCRQ_Localization::get_text( 'update_list' ) ); ?>"><?php echo esc_html( WPCRQ_Localization::get_text( 'update_list' ) ); ?></button>
                    </td>
                </tr>
                </tbody>
            </table>
        </form>
    </div>

    <div class="wpcrq-quote-form-wrapper">
        <?php
        $wpcrq_total_qty = WPCRQ_Session::get_total_quantity();
        $wpcrq_min_qty   = absint( WPCRQ_Settings::get_setting( 'min_qty', 0 ) );
        $wpcrq_max_qty   = absint( WPCRQ_Settings::get_setting( 'max_qty', 0 ) );

        $wpcrq_errors = [];
        if ( $wpcrq_min_qty > 0 && $wpcrq_total_qty < $wpcrq_min_qty ) {
            $wpcrq_errors[] = sprintf( WPCRQ_Localization::get_text( 'min_qty_error' ), $wpcrq_min_qty );
        }
        if ( $wpcrq_max_qty > 0 && $wpcrq_total_qty > $wpcrq_max_qty ) {
            $wpcrq_errors[] = sprintf( WPCRQ_Localization::get_text( 'max_qty_error' ), $wpcrq_max_qty );
        }

        if ( ! empty( $wpcrq_errors ) ) {
            foreach ( $wpcrq_errors as $wpcrq_error ) {
                echo '<div class="woocommerce-error" role="alert">' . wp_kses_post( $wpcrq_error ) . '</div>';
            }
            echo '</div></div>'; // Close wpcrq-quote-form-wrapper and wpcrq-quote-page

            return;
        }
        ?>
        <h3><?php echo esc_html( WPCRQ_Localization::get_text( 'send_your_request' ) ); ?></h3>
        <?php
        $wpcrq_current_user = wp_get_current_user();
        $wpcrq_first_name   = '';
        $wpcrq_last_name    = '';
        $wpcrq_email        = '';

        if ( $wpcrq_current_user->exists() ) {
            $wpcrq_first_name = $wpcrq_current_user->user_firstname ? $wpcrq_current_user->user_firstname : $wpcrq_current_user->display_name;
            $wpcrq_last_name  = $wpcrq_current_user->user_lastname;
            $wpcrq_email      = $wpcrq_current_user->user_email;
        }
        ?>
        <form id="wpcrq-quote-form" class="wpcrq-quote-form">
            <p class="form-row form-row-first">
                <label for="wpcrq_first_name"><?php echo esc_html( WPCRQ_Localization::get_text( 'first_name' ) ); ?>
                    <span class="required">*</span></label>
                <input type="text" class="input-text" name="first_name" id="wpcrq_first_name"
                       value="<?php echo esc_attr( $wpcrq_first_name ); ?>" required>
            </p>
            <p class="form-row form-row-last">
                <label for="wpcrq_last_name"><?php echo esc_html( WPCRQ_Localization::get_text( 'last_name' ) ); ?></label>
                <input type="text" class="input-text" name="last_name" id="wpcrq_last_name"
                       value="<?php echo esc_attr( $wpcrq_last_name ); ?>">
            </p>
            <div class="clear"></div>
            <p class="form-row form-row-first">
                <label for="wpcrq_email"><?php echo esc_html( WPCRQ_Localization::get_text( 'email' ) ); ?> <span
                            class="required">*</span></label>
                <input type="email" class="input-text" name="email" id="wpcrq_email"
                       value="<?php echo esc_attr( $wpcrq_email ); ?>" required>
            </p>
            <p class="form-row form-row-last">
                <label for="wpcrq_phone"><?php echo esc_html( WPCRQ_Localization::get_text( 'phone' ) ); ?></label>
                <input type="text" class="input-text" name="phone" id="wpcrq_phone">
            </p>
            <div class="clear"></div>
            <p class="form-row form-row-wide">
                <?php
                $wpcrq_max_length     = WPCRQ_Settings::get_setting( 'max_message_length', 255 );
                $wpcrq_maxlength_attr = ( $wpcrq_max_length !== '' && $wpcrq_max_length > 0 ) ? 'maxlength="' . esc_attr( $wpcrq_max_length ) . '"' : '';
                ?>
                <label for="wpcrq_message"><?php echo esc_html( WPCRQ_Localization::get_text( 'message' ) ); ?></label>
                <textarea class="input-text" name="message" id="wpcrq_message"
                          rows="4" <?php echo $wpcrq_maxlength_attr; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>></textarea>
            </p>
            <p class="form-row">
                <button type="submit" class="button alt"
                        id="wpcrq_submit_button"><?php echo esc_html( WPCRQ_Localization::get_text( 'send_request' ) ); ?></button>
            </p>
            <div class="wpcrq-form-response"></div>
        </form>
    </div>
</div>
