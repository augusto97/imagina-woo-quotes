<?php
/**
 * Template for viewing a quote request for review (Accept/Reject)
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header(); ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <article class="page type-page status-publish hentry">
                <header class="entry-header">
                    <h1 class="entry-title"><?php printf( esc_html( WPCRQ_Localization::get_text( 'quote_details_title' ) ), esc_html( $order->get_order_number() ) ); ?></h1>
                </header>

                <div class="entry-content">
                    <?php wc_print_notices(); ?>

                    <div class="wpcrq-quote-review-wrapper">
                        <?php if ( in_array( $order->get_status(), [ 'quote-pending', 'quote-request' ], true ) ) : ?>
                            <p><?php echo esc_html( WPCRQ_Localization::get_text( 'review_quote_msg' ) ); ?></p>
                        <?php else: ?>
                            <p><?php printf( esc_html( WPCRQ_Localization::get_text( 'status_label' ) ), esc_html( wc_get_order_status_name( $order->get_status() ) ) ); ?></p>
                        <?php endif; ?>

                        <table class="shop_table shop_table_responsive order_details">
                            <thead>
                            <tr>
                                <th class="product-name"><?php echo esc_html( WPCRQ_Localization::get_text( 'product' ) ); ?></th>
                                <th class="product-total"><?php echo esc_html( WPCRQ_Localization::get_text( 'total' ) ); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            foreach ( $order->get_items() as $wpcrq_item_id => $wpcrq_item ) {
                                $wpcrq_product = $wpcrq_item->get_product();
                                ?>
                                <tr class="woocommerce-table__line-item order_item">
                                    <td class="woocommerce-table__product-name product-name">
                                        <?php
                                        echo wp_kses_post( apply_filters( 'woocommerce_order_item_name', $wpcrq_item->get_name(), $wpcrq_item, false ) );
                                        do_action( 'woocommerce_order_item_meta_start', $wpcrq_item_id, $wpcrq_item, $order, false );
                                        wc_display_item_meta( $wpcrq_item );
                                        do_action( 'woocommerce_order_item_meta_end', $wpcrq_item_id, $wpcrq_item, $order, false );
                                        ?>
                                        <strong class="product-quantity">&times;&nbsp;<?php echo absint( $wpcrq_item->get_quantity() ); ?></strong>
                                    </td>
                                    <td class="woocommerce-table__product-total product-total">
                                        <?php echo wp_kses_post( $order->get_formatted_line_subtotal( $wpcrq_item ) ); ?>
                                    </td>
                                </tr>
                                <?php
                            }
                            ?>
                            </tbody>
                            <tfoot>
                            <?php
                            foreach ( $order->get_order_item_totals() as $wpcrq_total_key => $wpcrq_total ) {
                                ?>
                                <tr>
                                    <th scope="row"><?php echo esc_html( $wpcrq_total['label'] ); ?></th>
                                    <td><?php echo wp_kses_post( $wpcrq_total['value'] ); ?></td>
                                </tr>
                                <?php
                            }
                            ?>
                            </tfoot>
                        </table>

                        <div class="wpcrq-order-addresses" style="margin-bottom: 30px;">
                            <h3><?php esc_html_e( 'Shipping address', 'wpc-request-a-quote' ); ?></h3>
                            <address>
                                <?php
                                $wpcrq_address = $order->get_address( 'shipping' );
                                if ( ! empty( array_filter( $wpcrq_address ) ) ) {
                                    echo wp_kses_post( $order->get_formatted_shipping_address() );
                                } else {
                                    echo esc_html( WPCRQ_Localization::get_text( 'no_shipping_address' ) );
                                }
                                ?>
                            </address>
                        </div>

                        <?php if ( 'shipping' === $wpcrq_step ) : ?>
                            <div class="wpcrq-shipping-info-step" style="margin-top: 30px;">
                                <h3><?php echo esc_html( WPCRQ_Localization::get_text( 'shipping_info_title' ) ); ?></h3>
                                <p><?php echo esc_html( WPCRQ_Localization::get_text( 'shipping_info_msg' ) ); ?></p>

                                <form method="post" class="wpcrq-shipping-form">
                                    <?php wp_nonce_field( 'wpcrq_quote_action' ); ?>
                                    <input type="hidden" name="wpcrq_action" value="confirm_accept">

                                    <?php
                                    $wpcrq_customer = $order->get_customer_id() ? new WC_Customer( $order->get_customer_id() ) : null;

                                    $wpcrq_shipping_fields = [
                                            'first_name' => $order->get_shipping_first_name() ?: $order->get_billing_first_name(),
                                            'last_name'  => $order->get_shipping_last_name() ?: $order->get_billing_last_name(),
                                            'address_1'  => $order->get_shipping_address_1(),
                                            'address_2'  => $order->get_shipping_address_2(),
                                            'city'       => $order->get_shipping_city(),
                                            'postcode'   => $order->get_shipping_postcode(),
                                            'country'    => $order->get_shipping_country(),
                                            'state'      => $order->get_shipping_state(),
                                    ];

                                    if ( $wpcrq_customer ) {
                                        if ( empty( $wpcrq_shipping_fields['first_name'] ) ) {
                                            $wpcrq_shipping_fields['first_name'] = $wpcrq_customer->get_shipping_first_name() ?: $wpcrq_customer->get_billing_first_name();
                                        }
                                        if ( empty( $wpcrq_shipping_fields['last_name'] ) ) {
                                            $wpcrq_shipping_fields['last_name'] = $wpcrq_customer->get_shipping_last_name() ?: $wpcrq_customer->get_billing_last_name();
                                        }
                                        if ( empty( $wpcrq_shipping_fields['address_1'] ) ) {
                                            $wpcrq_shipping_fields['address_1'] = $wpcrq_customer->get_shipping_address_1() ?: $wpcrq_customer->get_billing_address_1();
                                        }
                                        if ( empty( $wpcrq_shipping_fields['address_2'] ) ) {
                                            $wpcrq_shipping_fields['address_2'] = $wpcrq_customer->get_shipping_address_2() ?: $wpcrq_customer->get_billing_address_2();
                                        }
                                        if ( empty( $wpcrq_shipping_fields['city'] ) ) {
                                            $wpcrq_shipping_fields['city'] = $wpcrq_customer->get_shipping_city() ?: $wpcrq_customer->get_billing_city();
                                        }
                                        if ( empty( $wpcrq_shipping_fields['postcode'] ) ) {
                                            $wpcrq_shipping_fields['postcode'] = $wpcrq_customer->get_shipping_postcode() ?: $wpcrq_customer->get_billing_postcode();
                                        }
                                        if ( empty( $wpcrq_shipping_fields['country'] ) ) {
                                            $wpcrq_shipping_fields['country'] = $wpcrq_customer->get_shipping_country() ?: $wpcrq_customer->get_billing_country();
                                        }
                                        if ( empty( $wpcrq_shipping_fields['state'] ) ) {
                                            $wpcrq_shipping_fields['state'] = $wpcrq_customer->get_shipping_state() ?: $wpcrq_customer->get_billing_state();
                                        }
                                    }
                                    ?>
                                    <div class="woocommerce-shipping-fields__field-wrapper"
                                         style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                                        <p class="form-row form-row-first">
                                            <label><?php esc_html_e( 'First name', 'wpc-request-a-quote' ); ?> <abbr
                                                        class="required" title="required">*</abbr></label>
                                            <input type="text" class="input-text" name="shipping_first_name"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['first_name'] ); ?>"
                                                   required>
                                        </p>
                                        <p class="form-row form-row-last">
                                            <label><?php esc_html_e( 'Last name', 'wpc-request-a-quote' ); ?> <abbr
                                                        class="required" title="required">*</abbr></label>
                                            <input type="text" class="input-text" name="shipping_last_name"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['last_name'] ); ?>"
                                                   required>
                                        </p>
                                        <p class="form-row form-row-wide" style="grid-column: span 2;">
                                            <label><?php esc_html_e( 'Address line 1', 'wpc-request-a-quote' ); ?> <abbr
                                                        class="required" title="required">*</abbr></label>
                                            <input type="text" class="input-text" name="shipping_address_1"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['address_1'] ); ?>"
                                                   required
                                                   placeholder="<?php esc_attr_e( 'House number and street name', 'wpc-request-a-quote' ); ?>">
                                        </p>
                                        <p class="form-row form-row-wide" style="grid-column: span 2;">
                                            <label><?php esc_html_e( 'Address line 2', 'wpc-request-a-quote' ); ?>
                                                (<?php esc_html_e( 'optional', 'wpc-request-a-quote' ); ?>)</label>
                                            <input type="text" class="input-text" name="shipping_address_2"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['address_2'] ); ?>"
                                                   placeholder="<?php esc_attr_e( 'Apartment, suite, unit, etc. (optional)', 'wpc-request-a-quote' ); ?>">
                                        </p>
                                        <p class="form-row form-row-first">
                                            <label><?php esc_html_e( 'Town / City', 'wpc-request-a-quote' ); ?> <abbr
                                                        class="required" title="required">*</abbr></label>
                                            <input type="text" class="input-text" name="shipping_city"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['city'] ); ?>" required>
                                        </p>
                                        <p class="form-row form-row-last">
                                            <label><?php esc_html_e( 'Postcode / ZIP', 'wpc-request-a-quote' ); ?> <abbr
                                                        class="required" title="required">*</abbr></label>
                                            <input type="text" class="input-text" name="shipping_postcode"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['postcode'] ); ?>"
                                                   required>
                                        </p>
                                        <p class="form-row form-row-first">
                                            <label><?php esc_html_e( 'Country / Region', 'wpc-request-a-quote' ); ?> <abbr
                                                        class="required" title="required">*</abbr></label>
                                            <input type="text" class="input-text" name="shipping_country"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['country'] ?: 'VN' ); ?>"
                                                   required>
                                        </p>
                                        <p class="form-row form-row-last">
                                            <label><?php esc_html_e( 'State / County', 'wpc-request-a-quote' ); ?> <abbr
                                                        class="required" title="required">*</abbr></label>
                                            <input type="text" class="input-text" name="shipping_state"
                                                   value="<?php echo esc_attr( $wpcrq_shipping_fields['state'] ); ?>"
                                                   required>
                                        </p>
                                    </div>

                                    <div class="wpcrq-quote-actions" style="margin-top: 30px;">
                                        <button type="submit" class="button alt"
                                                style="background-color: #96588a; color: #fff; font-weight: bold; width: 100%; padding: 15px;"><?php echo esc_html( WPCRQ_Localization::get_text( 'confirm_pay_btn' ) ); ?></button>
                                        <p style="margin-top: 10px; text-align: center;">
                                            <a href="<?php echo esc_url( remove_query_arg( [
                                                    'wpcrq_action',
                                                    '_wpnonce'
                                            ] ) ); ?>"
                                               style="text-decoration: none; font-size: 0.9em; color: #666;"><?php echo esc_html( WPCRQ_Localization::get_text( 'back_to_quote_link' ) ); ?></a>
                                        </p>
                                    </div>
                                </form>
                            </div>
                        <?php elseif ( in_array( $order->get_status(), [
                                'quote-pending',
                                'quote-request'
                        ], true ) ) : ?>
                            <div class="wpcrq-quote-actions" style="margin-top: 30px; display: flex; gap: 20px;">
                                <form method="post">
                                    <?php wp_nonce_field( 'wpcrq_quote_action' ); ?>
                                    <input type="hidden" name="wpcrq_action" value="accept">
                                    <button type="submit" class="button alt"
                                            style="background-color: #96588a; color: #fff; font-weight: bold;"><?php echo esc_html( WPCRQ_Localization::get_text( 'accept_pay_btn' ) ); ?></button>
                                </form>

                                <form method="post">
                                    <?php wp_nonce_field( 'wpcrq_quote_action' ); ?>
                                    <input type="hidden" name="wpcrq_action" value="reject">
                                    <button type="submit" class="button"
                                            style="background-color: #eee; color: #333;"><?php echo esc_html( WPCRQ_Localization::get_text( 'reject_quote_btn' ) ); ?></button>
                                </form>
                            </div>
                        <?php elseif ( 'pending' === $order->get_status() ) : ?>
                            <div class="woocommerce-message">
                                <?php echo esc_html( WPCRQ_Localization::get_text( 'accepted_awaiting_pay' ) ); ?>
                            </div>
                            <div class="wpcrq-quote-actions"
                                 style="margin-top: 20px; display: flex; gap: 15px; align-items: center;">
                                <a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>"
                                   class="button alt"
                                   style="background-color: #96588a; color: #fff; font-weight: bold; text-decoration: none; padding: 12px 25px; border-radius: 4px; display: inline-block;">
                                    <?php echo esc_html( WPCRQ_Localization::get_text( 'pay_now_btn' ) ); ?>
                                </a>

                                <form method="post" style="margin: 0;">
                                    <?php wp_nonce_field( 'wpcrq_quote_action' ); ?>
                                    <input type="hidden" name="wpcrq_action" value="accept">
                                    <button type="submit" class="button"
                                            style="background-color: #eee; color: #333;"><?php echo esc_html( WPCRQ_Localization::get_text( 'update_shipping_btn' ) ); ?></button>
                                </form>
                            </div>
                        <?php elseif ( 'quote-rejected' === $order->get_status() ) : ?>
                            <div class="woocommerce-info">
                                <?php echo esc_html( WPCRQ_Localization::get_text( 'quote_rejected_msg' ) ); ?>
                            </div>
                        <?php elseif ( ! in_array( $order->get_status(), [
                                'quote-pending',
                                'quote-request',
                                'pending',
                                'quote-rejected'
                        ] ) ) : ?>
                            <div class="woocommerce-info">
                                <?php printf( esc_html( WPCRQ_Localization::get_text( 'order_status_msg' ) ), esc_html( wc_get_order_status_name( $order->get_status() ) ) ); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </article>
        </main>
    </div>

<?php get_footer();
