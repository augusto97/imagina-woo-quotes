<?php
/**
 * Customer New Quote Request email
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<?php /* translators: %s: Customer first name */ ?>
    <p><?php printf( esc_html__( 'Hi %s,', 'wpc-request-a-quote' ), esc_html( $order->get_billing_first_name() ) ); ?></p>
    <p><?php esc_html_e( 'We have received your quote request and will contact you shortly. You can review the details of your request below:', 'wpc-request-a-quote' ); ?></p>

<?php
/*
 * @hooked woocommerce_email_order_details - 10
 * @hooked woocommerce_email_order_meta - 20
 * @hooked woocommerce_email_customer_details - 30
 */
WPCRQ_Emails::render_order_details( $order, $sent_to_admin, $plain_text, $email );
?>

    <?php // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce email template variable. ?>
    <p><?php echo esc_html( $additional_content ); ?></p>

<?php
do_action( 'woocommerce_email_footer', $email );
