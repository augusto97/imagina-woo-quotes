<?php
/**
 * Customer New Quote Request email (plain)
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo "= " . esc_html( $email_heading ) . " =\n\n";

/* translators: %s: Customer first name */
echo sprintf( esc_html__( 'Hi %s,', 'wpc-request-a-quote' ), esc_html( $order->get_billing_first_name() ) ) . "\n\n";
echo esc_html__( 'We have received your quote request and will contact you shortly. You can review the details of your request below:', 'wpc-request-a-quote' ) . "\n\n";

/*
 * @hooked woocommerce_email_order_details - 10
 * @hooked woocommerce_email_order_meta - 20
 * @hooked woocommerce_email_customer_details - 30
 */
WPCRQ_Emails::render_order_details( $order, $sent_to_admin, $plain_text, $email );

echo "\n-----------------------------------------------------------\n\n";

// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce email template variable.
echo esc_html( $additional_content ) . "\n\n";

do_action( 'woocommerce_email_footer', $email );
