<?php
/**
 * Customer Quote Updated email
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

<?php /* translators: %s: Customer first name */ ?>
    <p><?php printf( esc_html__( 'Hi %s,', 'wpc-request-a-quote' ), esc_html( $order->get_billing_first_name() ) ); ?></p>
    <p><?php esc_html_e( 'Your quote request has been updated by the administrator. You can review the updated prices and terms by clicking the button below:', 'wpc-request-a-quote' ); ?></p>

<?php
$wpcrq_review_url = add_query_arg( [
        'wpcrq-quote' => $order->get_id(),
        'key'         => $order->get_order_key(),
], home_url( '/' ) );
?>

    <p style="text-align: center; margin: 30px 0;">
        <a href="<?php echo esc_url( $wpcrq_review_url ); ?>"
           style="background-color: #96588a; color: #ffffff; padding: 15px 25px; text-decoration: none; border-radius: 3px; font-weight: bold; display: inline-block;">
            <?php esc_html_e( 'Review & Accept Quote', 'wpc-request-a-quote' ); ?>
        </a>
    </p>

<?php
/*
 * @hooked woocommerce_email_order_details - 10
 * @hooked woocommerce_email_order_meta - 20
 * @hooked woocommerce_email_customer_details - 30
 */
WPCRQ_Emails::render_order_details( $order, $sent_to_admin, $plain_text, $email );
?>

    <?php // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce email template variable. ?>
    <p><?php echo esc_html( $additional_content ); ?></p>

<?php
do_action( 'woocommerce_email_footer', $email );
