<?php
/**
 * Template for order not found or invalid key
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header(); ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <article class="page type-page status-publish hentry">
                <header class="entry-header">
                    <h1 class="entry-title"><?php esc_html_e( 'Order Not Found', 'wpc-request-a-quote' ); ?></h1>
                </header>

                <div class="entry-content">
                    <div class="woocommerce-error">
                        <?php esc_html_e( 'The requested order could not be found or the secure key is invalid. Please check your link and try again.', 'wpc-request-a-quote' ); ?>
                    </div>
                    <p>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="button">
                            <?php esc_html_e( 'Return to shop', 'wpc-request-a-quote' ); ?>
                        </a>
                    </p>
                </div>
            </article>
        </main>
    </div>

<?php get_footer();
